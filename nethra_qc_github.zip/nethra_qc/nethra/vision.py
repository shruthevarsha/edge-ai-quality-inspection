"""Vision pipeline: frame sources, golden-board comparison and the YOLO detector (ExecuTorch / ONNX Runtime).

This pipeline is completely separate from the Llama advisory pipeline (advisor.py)."""
from __future__ import annotations

import logging
import math
import threading
import time
from pathlib import Path
import cv2
import numpy as np
from .core import Detection

# ============================================================================
# camera
# ============================================================================
# Frame sources: USB/CSI camera (V4L2), Picamera2, video file, or a folder of images (demo / batch mode).
#
# Every source runs in its own thread and keeps only the newest frame, so a slow inspection never
# builds up a backlog of stale frames.
log = logging.getLogger(__name__)

IMG_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
TEMPLATE_SUFFIXES = ("_temp", "_template", "_ref", "_golden")


def find_reference_for(path: Path) -> Path | None:
    """DeepPCB-style pairing: 00041000_test.jpg <-> 00041000_temp.jpg (same folder)."""
    stem = path.stem
    base = stem[:-5] if stem.endswith("_test") else stem
    for suf in TEMPLATE_SUFFIXES:
        for ext in IMG_EXT:
            cand = path.with_name(f"{base}{suf}{ext}")
            if cand.exists() and cand != path:
                return cand
    return None


def is_template(path: Path) -> bool:
    return any(path.stem.endswith(s) for s in TEMPLATE_SUFFIXES)


class FrameSource:
    """Common interface. `read()` returns (frame_bgr, meta, seq) for the newest frame."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._frame: np.ndarray | None = None
        self._meta: dict = {}
        self._seq = 0
        self._running = False
        self._thread: threading.Thread | None = None
        self.kind = "base"
        self.error: str | None = None

    def start(self) -> "FrameSource":
        self._running = True
        self._thread = threading.Thread(target=self._loop, name=f"camera-{self.kind}", daemon=True)
        self._thread.start()
        return self

    def stop(self) -> None:
        self._running = False

    def _publish(self, frame: np.ndarray, meta: dict) -> None:
        with self._lock:
            self._frame = frame
            self._meta = meta
            self._seq += 1

    def read(self) -> tuple[np.ndarray | None, dict, int]:
        with self._lock:
            return self._frame, dict(self._meta), self._seq

    def _loop(self) -> None:  # pragma: no cover - overridden
        raise NotImplementedError


class FolderSource(FrameSource):
    """Cycles through the images in a folder. Template images (*_temp.*) are skipped and used as
    golden references for their matching *_test.* image."""

    def __init__(self, folder: str, interval_s: float = 4.0, loop: bool = True) -> None:
        super().__init__()
        self.kind = "folder"
        self.folder = Path(folder)
        self.interval_s = interval_s
        self.loop_forever = loop
        self.files = sorted(p for p in self.folder.rglob("*") if p.suffix.lower() in IMG_EXT and not is_template(p))
        if not self.files:
            self.error = f"No images found in {self.folder}"
        self.index = -1
        self._skip = threading.Event()

    def next(self) -> None:
        """Advance to the next image immediately (UI 'next part' button)."""
        self._skip.set()

    def _loop(self) -> None:
        item = 0
        while self._running and self.files:
            self.index = (self.index + 1) % len(self.files)
            if self.index == 0 and item > 0 and not self.loop_forever:
                break
            path = self.files[self.index]
            frame = cv2.imread(str(path), cv2.IMREAD_COLOR)
            if frame is None:
                log.warning("Could not read %s", path)
                continue
            ref = find_reference_for(path)
            item += 1
            self._publish(frame, {"path": str(path), "reference_path": str(ref) if ref else None,
                                  "item": item, "new_item": True, "kind": self.kind})
            self._skip.wait(self.interval_s)
            self._skip.clear()


class CaptureSource(FrameSource):
    """OpenCV VideoCapture: device index (USB webcam / Pi camera via libcamera V4L2 compat) or video file."""

    def __init__(self, source: str, width: int, height: int, fps: int, loop: bool = True) -> None:
        super().__init__()
        self.source = int(source) if str(source).isdigit() else source
        self.kind = "camera" if isinstance(self.source, int) else "video"
        self.width, self.height, self.fps, self.loop_forever = width, height, fps, loop

    def _open(self) -> cv2.VideoCapture:
        cap = cv2.VideoCapture(self.source)
        if self.kind == "camera":
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
            cap.set(cv2.CAP_PROP_FPS, self.fps)
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        return cap

    def _loop(self) -> None:
        cap = self._open()
        if not cap.isOpened():
            self.error = f"Cannot open camera/video source {self.source!r}"
            log.error(self.error)
            return
        delay = 1.0 / max(1, self.fps) if self.kind == "video" else 0.0
        n = 0
        while self._running:
            ok, frame = cap.read()
            if not ok:
                if self.kind == "video" and self.loop_forever:
                    cap.release()
                    cap = self._open()
                    continue
                self.error = "Frame grab failed"
                time.sleep(0.2)
                continue
            n += 1
            self._publish(frame, {"path": None, "reference_path": None, "item": n, "new_item": False, "kind": self.kind})
            if delay:
                time.sleep(delay)
        cap.release()


class Picamera2Source(FrameSource):
    """Raspberry Pi Camera Module through the Picamera2 library (installed by default on Raspberry Pi OS)."""

    def __init__(self, width: int, height: int) -> None:
        super().__init__()
        self.kind = "picamera2"
        self.width, self.height = width, height

    def _loop(self) -> None:
        try:
            from picamera2 import Picamera2  # type: ignore
        except ImportError:
            self.error = "picamera2 not installed (sudo apt install python3-picamera2)"
            log.error(self.error)
            return
        cam = Picamera2()
        cam.configure(cam.create_video_configuration(main={"size": (self.width, self.height), "format": "RGB888"}))
        cam.start()
        n = 0
        while self._running:
            frame = cam.capture_array()  # RGB888 in Picamera2 is laid out as BGR for OpenCV
            n += 1
            self._publish(frame, {"path": None, "reference_path": None, "item": n, "new_item": False, "kind": self.kind})
        cam.stop()


def open_source(cfg: dict) -> FrameSource:
    c = cfg["camera"]
    src = str(c["source"])
    if src == "picamera2":
        return Picamera2Source(c["width"], c["height"]).start()
    if Path(src).is_dir():
        return FolderSource(src, c.get("folder_interval_s", 4.0), c.get("loop", True)).start()
    return CaptureSource(src, c["width"], c["height"], c["fps"], c.get("loop", True)).start()


# ============================================================================
# reference
# ============================================================================
# Golden-board comparison (classical AOI) with OpenCV.
#
# Works with no training data: the inspected board is aligned to a known-good "golden" image, copper
# is segmented in both, and every region where copper was added or removed becomes a defect.
# The defect type is then inferred from *topology* — the same reasoning an AOI engineer uses:
#
#   extra copper that merges two separate conductors      -> short
#   extra copper attached to one conductor                -> spur
#   extra copper not touching any conductor               -> spurious_copper
#   missing copper that splits a conductor in two         -> open
#   missing copper fully enclosed by copper               -> pin_hole
#   missing copper biting into a conductor edge           -> mouse_bite
#
# This also acts as the "anomaly" path of the system: it flags any deviation from the golden board,
# including defect types a trained detector has never seen.
log = logging.getLogger(__name__)


def _components(mask: np.ndarray, min_area: int) -> int:
    n, _, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), connectivity=8)
    return int(sum(1 for i in range(1, n) if stats[i, cv2.CC_STAT_AREA] >= min_area))


class ReferenceInspector:
    def __init__(self, cfg: dict | None = None) -> None:
        cfg = cfg or {}
        self.align_enabled = cfg.get("align", True)
        self.diff_threshold = cfg.get("diff_threshold", 60)
        self.min_area = int(cfg.get("min_area_px", 12))
        self.blur = int(cfg.get("blur", 3))
        self.kernel = int(cfg.get("morph_kernel", 3))
        self.copper_bright = cfg.get("copper_bright", True)
        self.orb = cv2.ORB_create(3000)

    # ---------- preprocessing ----------
    def _gray(self, img: np.ndarray) -> np.ndarray:
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
        if self.blur >= 3:
            g = cv2.GaussianBlur(g, (self.blur | 1, self.blur | 1), 0)
        return g

    def _binarize(self, gray: np.ndarray) -> np.ndarray:
        mode = cv2.THRESH_BINARY if self.copper_bright else cv2.THRESH_BINARY_INV
        _, b = cv2.threshold(gray, 0, 255, mode | cv2.THRESH_OTSU)
        return (b > 0).astype(np.uint8)

    def align(self, test_gray: np.ndarray, ref_gray: np.ndarray) -> tuple[np.ndarray, np.ndarray, dict]:
        """Warp the reference onto the test image. Returns (aligned_ref, valid_mask, info)."""
        h, w = test_gray.shape[:2]
        valid = np.ones((h, w), np.uint8)
        if ref_gray.shape[:2] != (h, w):
            ref_gray = cv2.resize(ref_gray, (w, h), interpolation=cv2.INTER_AREA)
        info = {"aligned": False, "inliers": 0}
        if not self.align_enabled:
            return ref_gray, valid, info
        k1, d1 = self.orb.detectAndCompute(ref_gray, None)
        k2, d2 = self.orb.detectAndCompute(test_gray, None)
        if d1 is None or d2 is None or len(k1) < 10 or len(k2) < 10:
            return ref_gray, valid, info
        matches = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True).match(d1, d2)
        matches = sorted(matches, key=lambda m: m.distance)[:500]
        if len(matches) < 12:
            return ref_gray, valid, info
        src = np.float32([k1[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
        dst = np.float32([k2[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)
        H, inl = cv2.findHomography(src, dst, cv2.RANSAC, 3.0)
        n_in = int(inl.sum()) if inl is not None else 0
        if H is None or n_in < 15:
            return ref_gray, valid, info
        H = self._refine_ecc(test_gray, ref_gray, H)
        warped = cv2.warpPerspective(ref_gray, H, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        valid = cv2.warpPerspective(np.ones_like(ref_gray), H, (w, h), flags=cv2.INTER_NEAREST)
        valid = cv2.erode(valid, np.ones((5, 5), np.uint8))
        info.update(aligned=True, inliers=n_in)
        return warped, valid, info

    @staticmethod
    def _refine_ecc(test_gray: np.ndarray, ref_gray: np.ndarray, H: np.ndarray, scale: float = 0.5) -> np.ndarray:
        """Sub-pixel refinement of the ORB homography with ECC (done at half resolution for speed)."""
        h, w = test_gray.shape[:2]
        S = np.diag([scale, scale, 1.0])
        Hs = S @ H @ np.linalg.inv(S)
        small_t = cv2.resize(test_gray, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
        small_r = cv2.resize(ref_gray, (int(ref_gray.shape[1] * scale), int(ref_gray.shape[0] * scale)), interpolation=cv2.INTER_AREA)
        warp = Hs.astype(np.float32)
        try:
            crit = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 60, 1e-6)
            # ECC maps template (test) coords -> input (ref) coords, so start from the inverse
            inv = np.linalg.inv(warp).astype(np.float32)
            _, inv = cv2.findTransformECC(small_t, small_r, inv, cv2.MOTION_HOMOGRAPHY, crit, None, 5)
            warp = np.linalg.inv(inv)
        except cv2.error:
            return H
        return np.linalg.inv(S) @ warp @ S

    # ---------- main entry ----------
    def compare(self, test_bgr: np.ndarray, ref_bgr: np.ndarray) -> tuple[list[Detection], dict]:
        tg, rg = self._gray(test_bgr), self._gray(ref_bgr)
        rg, valid, info = self.align(tg, rg)
        t, r = self._binarize(tg), self._binarize(rg)
        h, w = t.shape
        extra = t & (1 - r) & valid
        missing = r & (1 - t) & valid
        # Opening removes the 1-2 px slivers left along conductor edges by residual misalignment
        mk = np.ones((self.kernel, self.kernel), np.uint8)
        extra = cv2.morphologyEx(extra, cv2.MORPH_OPEN, mk)
        missing = cv2.morphologyEx(missing, cv2.MORPH_OPEN, mk)

        changed = float(extra.sum() + missing.sum()) / max(1, int(valid.sum()))
        info["changed_frac"] = round(changed, 5)
        if changed > 0.08:
            # Too much difference to be a few defects: wrong board, flipped part or failed alignment
            info["mismatch"] = True
            return [Detection("anomaly", 0.9, (0, 0, w - 1, h - 1), "reference", 1.0,
                              notes=["board does not match the golden reference (wrong part, orientation or alignment)"])], info

        # "Core" pixels lie more than 1 px from the other image's conductor edge. Real defects have a
        # core; slivers from residual misalignment along long edges do not.
        k3 = np.ones((3, 3), np.uint8)
        cores = {"extra": extra & (1 - cv2.dilate(r, k3)), "missing": missing & (1 - cv2.dilate(t, k3))}
        dets: list[Detection] = []
        for kind, mask in (("extra", extra), ("missing", missing)):
            n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
            for i in range(1, n):
                x, y, bw, bh, area = (int(v) for v in stats[i])
                if area < self.min_area:
                    continue
                blob = (labels == i).astype(np.uint8)
                if int((blob & cores[kind]).sum()) < 3:
                    continue
                cls = self._classify(kind, blob, (x, y, bw, bh), t, r)
                conf = float(np.clip(0.55 + 0.12 * math.log10(area), 0.5, 0.95))
                pad = 3
                box = (max(0, x - pad), max(0, y - pad), min(w - 1, x + bw + pad), min(h - 1, y + bh + pad))
                dets.append(Detection(cls, conf, box, "reference", (bw * bh) / float(w * h)))
        info["n_raw"] = len(dets)
        return dets, info

    def _classify(self, kind: str, blob: np.ndarray, rect, t: np.ndarray, r: np.ndarray) -> str:
        x, y, bw, bh = rect
        h, w = t.shape
        pad = max(10, int(1.5 * max(bw, bh)))
        x0, y0, x1, y1 = max(0, x - pad), max(0, y - pad), min(w, x + bw + pad), min(h, y + bh + pad)
        t_roi, r_roi, b_roi = t[y0:y1, x0:x1], r[y0:y1, x0:x1], blob[y0:y1, x0:x1]
        ma = max(4, self.min_area // 2)
        n_ref, n_test = _components(r_roi, ma), _components(t_roi, ma)
        # ring a few pixels outside the blob: is it surrounded by copper?
        ring = cv2.dilate(b_roi, np.ones((9, 9), np.uint8)) & (1 - cv2.dilate(b_roi, np.ones((5, 5), np.uint8)))
        ring_px = max(1, int(ring.sum()))
        if kind == "extra":
            if n_test < n_ref:
                return "short"
            touches = int((ring & r_roi).sum()) > 0
            return "spur" if touches else "spurious_copper"
        # missing copper
        if n_test > n_ref:
            return "open"
        enclosed = (ring & t_roi).sum() / ring_px
        return "pin_hole" if enclosed > 0.92 else "mouse_bite"


# ============================================================================
# detector
# ============================================================================
# Vision pipeline: YOLO defect detector (ExecuTorch or ONNX Runtime) + golden-reference comparison.
#
# This pipeline is completely separate from the Llama advisory pipeline (see advisor.py). On a
# Raspberry Pi 5 with an AI HAT+, a HailoRT backend can be added here behind the same interface;
# Llama keeps running on the Arm CPU through ExecuTorch either way.
log = logging.getLogger(__name__)


# ---------------------------------------------------------------- YOLO pre/post-processing
def letterbox(img: np.ndarray, size: int) -> tuple[np.ndarray, float, tuple[int, int]]:
    h, w = img.shape[:2]
    r = min(size / h, size / w)
    nh, nw = int(round(h * r)), int(round(w * r))
    resized = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_LINEAR)
    top, left = (size - nh) // 2, (size - nw) // 2
    out = np.full((size, size, 3), 114, np.uint8)
    out[top:top + nh, left:left + nw] = resized
    return out, r, (left, top)


def preprocess(img: np.ndarray, size: int) -> tuple[np.ndarray, float, tuple[int, int]]:
    lb, r, pad = letterbox(img, size)
    x = cv2.cvtColor(lb, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    return np.ascontiguousarray(x.transpose(2, 0, 1)[None]), r, pad


def decode_yolo(out: np.ndarray, classes: list[str], conf_t: float, iou_t: float,
                r: float, pad: tuple[int, int], shape: tuple[int, int]) -> list[Detection]:
    """Decode Ultralytics output into detections. Supports
      - YOLOv8 / YOLO11 raw head: (1, 4+nc, N) or (1, N, 4+nc), boxes cx,cy,w,h  -> NMS here
      - NMS-free end-to-end heads (YOLO26 / YOLOv10): (1, K, 6) = x1,y1,x2,y2,score,class
    """
    p = np.asarray(out)
    if p.ndim == 3:
        p = p[0]
    nc = len(classes)
    if p.ndim == 2 and p.shape[1] == 6 and p.shape[0] != 6 and nc + 4 != 6:
        return _decode_end2end(p, classes, conf_t, r, pad, shape)
    if p.shape[0] == 4 + nc and p.shape[1] != 4 + nc:
        p = p.T
    boxes, scores = p[:, :4], p[:, 4:4 + nc]
    cls_id = scores.argmax(1)
    conf = scores[np.arange(len(scores)), cls_id]
    keep = conf >= conf_t
    if not keep.any():
        return []
    boxes, conf, cls_id = boxes[keep], conf[keep], cls_id[keep]
    xyxy = np.empty_like(boxes)
    xyxy[:, 0] = (boxes[:, 0] - boxes[:, 2] / 2 - pad[0]) / r
    xyxy[:, 1] = (boxes[:, 1] - boxes[:, 3] / 2 - pad[1]) / r
    xyxy[:, 2] = (boxes[:, 0] + boxes[:, 2] / 2 - pad[0]) / r
    xyxy[:, 3] = (boxes[:, 1] + boxes[:, 3] / 2 - pad[1]) / r
    h, w = shape
    xyxy[:, [0, 2]] = xyxy[:, [0, 2]].clip(0, w - 1)
    xyxy[:, [1, 3]] = xyxy[:, [1, 3]].clip(0, h - 1)
    # class-aware NMS: offset boxes per class so different classes never suppress each other
    off = cls_id[:, None] * 4096.0
    nms_boxes = [[float(b[0] + o), float(b[1] + o), float(b[2] - b[0]), float(b[3] - b[1])] for b, o in zip(xyxy, off[:, 0])]
    idx = cv2.dnn.NMSBoxes(nms_boxes, conf.astype(float).tolist(), conf_t, iou_t)
    idx = np.array(idx).reshape(-1) if len(idx) else []
    dets = []
    for i in idx:
        x1, y1, x2, y2 = (int(v) for v in xyxy[i])
        dets.append(Detection(classes[int(cls_id[i])], float(conf[i]), (x1, y1, x2, y2), "yolo",
                              ((x2 - x1) * (y2 - y1)) / float(w * h)))
    return dets


def _decode_end2end(p: np.ndarray, classes: list[str], conf_t: float, r: float, pad: tuple[int, int],
                    shape: tuple[int, int]) -> list[Detection]:
    h, w = shape
    dets = []
    for x1, y1, x2, y2, s, c in p:
        if s < conf_t or int(c) >= len(classes):
            continue
        b = [int(np.clip((x1 - pad[0]) / r, 0, w - 1)), int(np.clip((y1 - pad[1]) / r, 0, h - 1)),
             int(np.clip((x2 - pad[0]) / r, 0, w - 1)), int(np.clip((y2 - pad[1]) / r, 0, h - 1))]
        dets.append(Detection(classes[int(c)], float(s), tuple(b), "yolo", ((b[2] - b[0]) * (b[3] - b[1])) / float(w * h)))
    return dets


def iou(a, b) -> float:
    ix1, iy1, ix2, iy2 = max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3])
    inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua > 0 else 0.0


# ---------------------------------------------------------------- backends
class ExecuTorchBackend:
    """YOLO lowered to XNNPACK and serialized as .pte, executed by the ExecuTorch runtime."""
    name = "executorch"

    def __init__(self, path: str, threads: int = 4) -> None:
        if not Path(path).exists():
            raise FileNotFoundError(path)
        import torch  # noqa: F401  (ExecuTorch Python runtime takes torch tensors)
        from executorch.runtime import Runtime  # type: ignore
        torch.set_num_threads(threads)
        self._torch = torch
        self.method = Runtime.get().load_program(path).load_method("forward")

    def __call__(self, x: np.ndarray) -> np.ndarray:
        out = self.method.execute([self._torch.from_numpy(x)])
        o = out[0] if isinstance(out, (list, tuple)) else out
        return o.numpy() if hasattr(o, "numpy") else np.asarray(o)


class OnnxBackend:
    name = "onnx"

    def __init__(self, path: str, threads: int = 4) -> None:
        if not Path(path).exists():
            raise FileNotFoundError(path)
        import onnxruntime as ort
        so = ort.SessionOptions()
        so.intra_op_num_threads = threads
        self.sess = ort.InferenceSession(path, so, providers=["CPUExecutionProvider"])
        self.inp = self.sess.get_inputs()[0].name

    def __call__(self, x: np.ndarray) -> np.ndarray:
        return self.sess.run(None, {self.inp: x})[0]


# ---------------------------------------------------------------- facade
class Detector:
    def __init__(self, cfg: dict) -> None:
        d = cfg["detector"]
        self.classes = list(d["classes"])
        self.size = int(d["input_size"])
        self.conf_t, self.iou_t = float(d["conf_threshold"]), float(d["iou_threshold"])
        self.use_reference = bool(d.get("use_reference_for_anomalies", True))
        self.reference = ReferenceInspector(cfg.get("reference", {}))
        self.backend = None
        self.backend_errors: dict[str, str] = {}
        for name in d["backends"]:
            if name == "reference":
                break
            try:
                if name == "executorch":
                    self.backend = ExecuTorchBackend(d["executorch_model"], d.get("threads", 4))
                elif name == "onnx":
                    self.backend = OnnxBackend(d["onnx_model"], d.get("threads", 4))
                else:
                    raise ValueError(f"unknown backend {name}")
                log.info("Vision backend: %s", name)
                break
            except Exception as e:  # missing model file / runtime not installed
                self.backend_errors[name] = f"{type(e).__name__}: {e}"
        self.last_latency_ms = 0.0

    @property
    def backend_name(self) -> str:
        return self.backend.name if self.backend else "reference-only"

    def detect(self, img: np.ndarray, reference: np.ndarray | None) -> tuple[list[Detection], dict]:
        t0 = time.perf_counter()
        info: dict = {"backend": self.backend_name}
        dets: list[Detection] = []
        if self.backend is not None:
            x, r, pad = preprocess(img, self.size)
            t1 = time.perf_counter()
            out = self.backend(x)
            info["yolo_ms"] = round((time.perf_counter() - t1) * 1000, 1)
            dets = decode_yolo(out, self.classes, self.conf_t, self.iou_t, r, pad, img.shape[:2])
        if reference is not None and (self.backend is None or self.use_reference):
            t1 = time.perf_counter()
            ref_dets, rinfo = self.reference.compare(img, reference)
            info["reference_ms"] = round((time.perf_counter() - t1) * 1000, 1)
            info["reference"] = rinfo
            for rd in ref_dets:
                # Keep reference findings that YOLO did not already explain
                if not any(iou(rd.box, yd.box) > 0.1 for yd in dets):
                    if self.backend is not None:
                        rd.notes.append("found by golden-board comparison (not by the trained detector)")
                    dets.append(rd)
        elif reference is None and self.backend is None:
            info["warning"] = "No trained detector and no golden reference — set a reference board to inspect."
        self.last_latency_ms = (time.perf_counter() - t0) * 1000
        info["total_ms"] = round(self.last_latency_ms, 1)
        return dets, info
