"""Core: configuration, data types, severity rules, SOP knowledge base, inspection log, GPIO alerts."""
from __future__ import annotations

import copy
import csv
import io
import json
import logging
import os
import sqlite3
import threading
import time
from collections import Counter
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any
import yaml


# ============================================================================
# config
# ============================================================================
# Configuration loading. Every relative path in config.yaml is resolved against the project root.
ROOT = Path(__file__).resolve().parent.parent

_PATH_KEYS = {
    ("app", "data_dir"),
    ("detector", "executorch_model"),
    ("detector", "onnx_model"),
    ("advisor", "runner"),
    ("advisor", "model"),
    ("advisor", "tokenizer"),
    ("advisor", "knowledge_base"),
    ("inspection", "reference_image"),
}


def resolve(p: str | os.PathLike | None) -> Path | None:
    if p is None or str(p).strip() == "":
        return None
    p = Path(os.path.expanduser(str(p)))
    return p if p.is_absolute() else (ROOT / p)


def _deep_update(base: dict, override: dict) -> dict:
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _deep_update(base[k], v)
        else:
            base[k] = v
    return base


def load_config(path: str | os.PathLike | None = None, overrides: dict | None = None) -> dict[str, Any]:
    path = Path(path) if path else ROOT / "config.yaml"
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    if overrides:
        cfg = _deep_update(copy.deepcopy(cfg), overrides)
    for section, key in _PATH_KEYS:
        if section in cfg and key in cfg[section]:
            r = resolve(cfg[section][key])
            cfg[section][key] = str(r) if r else ""
    src = str(cfg.get("camera", {}).get("source", "0"))
    # A camera source that is not a device index / special name is treated as a path
    if not src.isdigit() and src not in ("picamera2",) and "://" not in src:
        cfg["camera"]["source"] = str(resolve(src))
    Path(cfg["app"]["data_dir"]).mkdir(parents=True, exist_ok=True)
    return cfg


# ============================================================================
# types
# ============================================================================
@dataclass
class Detection:
    cls: str
    conf: float
    box: tuple[int, int, int, int]          # x1, y1, x2, y2 in original image pixels
    source: str = "yolo"                     # "yolo" | "reference"
    area_frac: float = 0.0                   # box area / image area
    severity: str = ""                       # minor | major | critical (filled by severity engine)
    location: str = ""                       # human-readable zone, e.g. "top-left"
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["box"] = [int(v) for v in self.box]
        d["conf"] = round(float(self.conf), 3)
        d["notes"] = [str(n) for n in self.notes]
        d["area_frac"] = round(float(self.area_frac), 5)
        return d


@dataclass
class Assessment:
    verdict: str                             # PASS | REWORK | REJECT
    score: int                               # 0..100 quality score
    detections: list[Detection]
    reasons: list[str]

    @property
    def counts(self) -> dict[str, int]:
        c: dict[str, int] = {}
        for d in self.detections:
            c[d.cls] = c.get(d.cls, 0) + 1
        return c

    def signature(self) -> str:
        """Stable key describing the defect pattern — used to cache Llama advice."""
        parts = sorted(f"{d.cls}:{d.severity}" for d in self.detections)
        return f"{self.verdict}|" + ",".join(parts)


# ============================================================================
# severity
# ============================================================================
# Deterministic severity engine.
#
# Pass/fail decisions are made by explicit, auditable rules — never by the language model. Llama only
# explains the decision and recommends actions (advisor.py).
LEVELS = ["minor", "major", "critical"]
WEIGHT = {"minor": 5, "major": 20, "critical": 45}


def zone(box, shape) -> str:
    h, w = shape[:2]
    cx, cy = (box[0] + box[2]) / 2 / w, (box[1] + box[3]) / 2 / h
    v = "top" if cy < 1 / 3 else ("bottom" if cy > 2 / 3 else "middle")
    hz = "left" if cx < 1 / 3 else ("right" if cx > 2 / 3 else "center")
    return "center" if (v, hz) == ("middle", "center") else f"{v}-{hz}"


def assess(dets: list[Detection], shape, cfg: dict) -> Assessment:
    s = cfg["severity"]
    base = s["base"]
    reasons: list[str] = []
    for d in dets:
        lvl = base.get(d.cls, "major")
        if d.area_frac > s["large_area_frac"] and lvl != "critical":
            lvl = LEVELS[LEVELS.index(lvl) + 1]
            d.notes.append("large defect area — escalated")
        if d.conf < s["low_confidence"]:
            d.notes.append("low confidence — verify manually")
        d.severity = lvl
        d.location = zone(d.box, shape)

    crit = [d for d in dets if d.severity == "critical"]
    major = [d for d in dets if d.severity == "major"]
    minor = [d for d in dets if d.severity == "minor"]
    if crit:
        verdict = "REJECT"
        reasons.append(f"{len(crit)} critical defect(s): " + ", ".join(sorted({d.cls for d in crit})))
    elif major:
        verdict = "REWORK"
        reasons.append(f"{len(major)} major defect(s): " + ", ".join(sorted({d.cls for d in major})))
    elif len(minor) >= s["minor_count_for_rework"]:
        verdict = "REWORK"
        reasons.append(f"{len(minor)} minor defects on one board (limit {s['minor_count_for_rework'] - 1})")
    else:
        verdict = "PASS"
        reasons.append("no defects found" if not dets else f"{len(minor)} minor cosmetic defect(s) within limit")
    if any("verify manually" in n for d in dets for n in d.notes):
        reasons.append("some detections have low confidence — operator verification advised")
    score = max(0, 100 - sum(WEIGHT[d.severity] for d in dets))
    dets.sort(key=lambda d: (-LEVELS.index(d.severity), -d.conf))
    return Assessment(verdict, score, dets, reasons)


# ============================================================================
# knowledge
# ============================================================================
# SOP knowledge base that grounds the Llama advisor.
class KnowledgeBase:
    def __init__(self, path: str) -> None:
        self.path = Path(path)
        data = yaml.safe_load(self.path.read_text(encoding="utf-8")) if self.path.exists() else {}
        self.domain = data.get("domain", "")
        self.station_notes = (data.get("station_notes") or "").strip()
        self.defects: dict[str, dict] = data.get("defects", {})
        self.verdict_actions: dict[str, str] = data.get("verdict_actions", {})

    def entry(self, cls: str) -> dict:
        return self.defects.get(cls) or self.defects.get("anomaly", {})

    def name(self, cls: str) -> str:
        return self.entry(cls).get("name", cls.replace("_", " "))

    def snippet(self, cls: str, max_items: int = 3) -> str:
        e = self.entry(cls)
        causes = "; ".join(e.get("likely_causes", [])[:max_items])
        actions = "; ".join(e.get("actions", [])[:max_items])
        return (f"[{cls}] {e.get('name', cls)} — {e.get('what', '')} Process area: {e.get('process_area', '?')}. "
                f"Likely causes: {causes}. Actions: {actions}. Acceptance: {e.get('acceptance', '?')}.")

    def classes_in_text(self, text: str) -> list[str]:
        t = text.lower()
        found = []
        for cls, e in self.defects.items():
            keys = {cls, cls.replace("_", " "), e.get("name", "").lower()}
            if any(k and k in t for k in keys):
                found.append(cls)
        return found


# ============================================================================
# store
# ============================================================================
# Inspection log — SQLite (single file, works offline, survives power loss) + CSV export.
SCHEMA = """
CREATE TABLE IF NOT EXISTS inspections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    station TEXT,
    source TEXT,
    image_path TEXT,
    annotated_path TEXT,
    verdict TEXT,
    score INTEGER,
    n_defects INTEGER,
    defects_json TEXT,
    reasons_json TEXT,
    vision_backend TEXT,
    vision_ms REAL,
    advice_json TEXT,
    advice_backend TEXT,
    advice_ms REAL,
    operator_action TEXT,
    operator_note TEXT,
    final_verdict TEXT
);
CREATE INDEX IF NOT EXISTS idx_ts ON inspections(ts);
CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, since REAL, until REAL, stats_json TEXT, summary TEXT, backend TEXT
);
"""


class InspectionStore:
    def __init__(self, data_dir: str) -> None:
        self.dir = Path(data_dir)
        (self.dir / "images").mkdir(parents=True, exist_ok=True)
        self.db_path = self.dir / "inspections.db"
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript(SCHEMA)
        self.lock = threading.Lock()

    def add(self, **kw) -> int:
        kw.setdefault("ts", time.time())
        kw["final_verdict"] = kw.get("verdict")
        for k in ("defects", "reasons"):
            if k in kw:
                kw[f"{k}_json"] = json.dumps(kw.pop(k))
        cols = ",".join(kw)
        with self.lock:
            cur = self.conn.execute(f"INSERT INTO inspections ({cols}) VALUES ({','.join('?' * len(kw))})", list(kw.values()))
            self.conn.commit()
            return int(cur.lastrowid)

    def set_advice(self, iid: int, advice: dict) -> None:
        with self.lock:
            self.conn.execute("UPDATE inspections SET advice_json=?, advice_backend=?, advice_ms=? WHERE id=?",
                              (json.dumps(advice), advice.get("backend"), advice.get("latency_ms"), iid))
            self.conn.commit()

    def set_operator(self, iid: int, action: str, note: str = "") -> dict | None:
        final = {"confirm": None, "override_pass": "PASS", "send_rework": "REWORK", "reject": "REJECT"}.get(action)
        with self.lock:
            if final:
                self.conn.execute("UPDATE inspections SET operator_action=?, operator_note=?, final_verdict=? WHERE id=?",
                                  (action, note, final, iid))
            else:
                self.conn.execute("UPDATE inspections SET operator_action=?, operator_note=? WHERE id=?", (action, note, iid))
            self.conn.commit()
        return self.get(iid)

    @staticmethod
    def _row(r: sqlite3.Row) -> dict:
        d = dict(r)
        d["defects"] = json.loads(d.pop("defects_json") or "[]")
        d["reasons"] = json.loads(d.pop("reasons_json") or "[]")
        d["advice"] = json.loads(d.pop("advice_json") or "null")
        return d

    def get(self, iid: int) -> dict | None:
        with self.lock:
            r = self.conn.execute("SELECT * FROM inspections WHERE id=?", (iid,)).fetchone()
        return self._row(r) if r else None

    def list(self, limit: int = 100, verdict: str | None = None, since: float | None = None, offset: int = 0) -> list[dict]:
        q, args = "SELECT * FROM inspections WHERE 1=1", []
        if verdict:
            q += " AND final_verdict=?"
            args.append(verdict)
        if since:
            q += " AND ts>=?"
            args.append(since)
        q += " ORDER BY id DESC LIMIT ? OFFSET ?"
        args += [limit, offset]
        with self.lock:
            rows = self.conn.execute(q, args).fetchall()
        return [self._row(r) for r in rows]

    def stats(self, since: float | None = None, until: float | None = None, station: str = "") -> dict:
        since = since or (time.time() - 8 * 3600)
        until = until or time.time()
        with self.lock:
            rows = self.conn.execute("SELECT ts, final_verdict, defects_json, operator_action FROM inspections WHERE ts BETWEEN ? AND ?",
                                     (since, until)).fetchall()
        by_v = Counter(r["final_verdict"] for r in rows)
        defects = Counter(d["cls"] for r in rows for d in json.loads(r["defects_json"] or "[]"))
        hours = Counter(time.strftime("%H:00", time.localtime(r["ts"])) for r in rows)
        total = len(rows)
        return {
            "station": station,
            "since": time.strftime("%Y-%m-%d %H:%M", time.localtime(since)),
            "until": time.strftime("%Y-%m-%d %H:%M", time.localtime(until)),
            "since_ts": since, "until_ts": until,
            "total": total,
            "by_verdict": {k: by_v.get(k, 0) for k in ("PASS", "REWORK", "REJECT")},
            "yield_pct": round(100 * by_v.get("PASS", 0) / total, 1) if total else 0.0,
            "top_defects": defects.most_common(6),
            "per_hour": sorted(hours.items()),
            "peak_hour": hours.most_common(1)[0][0] if hours else None,
            "overrides": sum(1 for r in rows if r["operator_action"] in ("override_pass", "send_rework", "reject")),
        }

    def save_report(self, stats: dict, summary: str, backend: str) -> int:
        with self.lock:
            cur = self.conn.execute("INSERT INTO reports (ts, since, until, stats_json, summary, backend) VALUES (?,?,?,?,?,?)",
                                    (time.time(), stats["since_ts"], stats["until_ts"], json.dumps(stats), summary, backend))
            self.conn.commit()
            return int(cur.lastrowid)

    def export_csv(self, since: float | None = None) -> str:
        rows = self.list(limit=1_000_000, since=since)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["id", "timestamp", "station", "source", "verdict", "final_verdict", "score", "n_defects", "defects",
                    "vision_backend", "vision_ms", "advice_alert", "advice_backend", "operator_action", "operator_note", "image"])
        for r in reversed(rows):
            w.writerow([r["id"], time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(r["ts"])), r["station"], r["source"],
                        r["verdict"], r["final_verdict"], r["score"], r["n_defects"],
                        "; ".join(f"{d['cls']}/{d['severity']}@{d['location']}" for d in r["defects"]),
                        r["vision_backend"], r["vision_ms"], (r["advice"] or {}).get("alert", ""), r["advice_backend"],
                        r["operator_action"], r["operator_note"], r["image_path"]])
        return buf.getvalue()


# ============================================================================
# alerts
# ============================================================================
# Physical alerts on the factory floor: stack light / buzzer through Raspberry Pi GPIO (optional).
# The browser UI additionally shows a full-width banner and plays a beep.
log = logging.getLogger(__name__)


class GpioAlerts:
    def __init__(self, cfg: dict) -> None:
        g = cfg.get("alerts", {}).get("gpio", {})
        self.enabled = bool(g.get("enabled"))
        self.leds = {}
        if not self.enabled:
            return
        try:
            from gpiozero import LED  # type: ignore
            self.leds = {"REJECT": LED(g["reject_pin"]), "REWORK": LED(g["rework_pin"]), "PASS": LED(g["pass_pin"])}
        except Exception as e:  # not on a Pi / gpiozero missing
            log.warning("GPIO alerts disabled: %s", e)
            self.enabled = False

    def signal(self, verdict: str, seconds: float = 2.0) -> None:
        if not self.enabled:
            return
        for v, led in self.leds.items():
            led.on() if v == verdict else led.off()
        led = self.leds.get(verdict)
        if led:
            threading.Timer(seconds, led.off).start()
