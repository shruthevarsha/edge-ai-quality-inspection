// NethraQC operator UI — vanilla JS, no external assets (works fully offline).
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const api = async (url, opt = {}) => {
  const r = await fetch(url, opt);
  if (!r.ok) throw new Error(`${r.status} ${await r.text()}`);
  return r.json();
};
const post = (url, body) => api(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
const SOUND = document.body.dataset.sound === "1";

// ---------------- tabs
$$("nav button").forEach((b) => b.addEventListener("click", () => {
  $$("nav button").forEach((x) => x.classList.toggle("active", x === b));
  $$(".tab").forEach((t) => t.classList.toggle("active", t.id === "tab-" + b.dataset.tab));
  if (b.dataset.tab === "log") loadLog();
  if (b.dataset.tab === "system") loadStatus();
}));

// ---------------- audio alert (generated, no files)
let actx;
function beep(verdict) {
  if (!SOUND) return;
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const pattern = verdict === "REJECT" ? [880, 0, 880, 0, 880] : [660, 0, 660];
    pattern.forEach((f, i) => {
      if (!f) return;
      const o = actx.createOscillator(), g = actx.createGain();
      o.frequency.value = f; o.type = "square"; g.gain.value = 0.05;
      o.connect(g); g.connect(actx.destination);
      const t = actx.currentTime + i * 0.12; o.start(t); o.stop(t + 0.1);
    });
  } catch (e) { /* audio blocked until first user gesture */ }
}

// ---------------- inspect tab
let shownId = null, shownAdvice = null, bannerTimer;
function sevBadge(s) { return `<span class="sev ${esc(s)}">${esc(s)}</span>`; }

function renderAdvice(adv) {
  if (!adv) return `<span class="muted">Llama is generating advice…</span>`;
  if (adv.error) return `<span class="muted">Advisor error: ${esc(adv.error)}</span>`;
  const acts = (adv.actions || []).map((a) => `<li>${esc(a)}</li>`).join("");
  const st = adv.stats || {};
  const meta = [adv.backend, adv.cached ? "cached" : null,
    adv.latency_ms != null ? `${(adv.latency_ms / 1000).toFixed(1)} s` : null,
    st.tokens_per_s ? `${st.tokens_per_s} tok/s` : null].filter(Boolean).join(" · ");
  const body = (adv.alert || acts || adv.root_cause)
    ? `<div class="alert">${esc(adv.alert)}</div>${acts ? `<ul>${acts}</ul>` : ""}${adv.root_cause ? `<div class="rc"><b>Likely root cause:</b> ${esc(adv.root_cause)}</div>` : ""}`
    : `<div>${esc(adv.raw)}</div>`;
  return body + `<div class="meta">${esc(meta)}</div>`;
}

function renderLatest(r) {
  if (!r) return;
  const card = $("#verdict-card");
  const v = r.final_verdict || r.verdict;
  card.className = "panel verdict " + v;
  $("#verdict").textContent = v + (r.final_verdict && r.final_verdict !== r.verdict ? " *" : "");
  $("#score").textContent = `score ${r.score}`;
  $("#ins-id").textContent = `#${r.id} · ${r.time.slice(11)} · ${r.vision_backend} ${Math.round(r.vision_ms)} ms`;
  $("#reasons").innerHTML = (r.reasons || []).map((x) => `<li>${esc(x)}</li>`).join("") +
    (r.operator_action ? `<li>Operator: <b>${esc(r.operator_action)}</b> ${esc(r.operator_note || "")}</li>` : "");
  $("#defects").innerHTML = r.defects.length
    ? r.defects.map((d, i) => `<tr><td>${i + 1}</td><td>${esc(d.cls)}${d.notes.length ? `<div class="muted small">${esc(d.notes.join("; "))}</div>` : ""}</td><td>${sevBadge(d.severity)}</td><td>${esc(d.location)}</td><td>${d.conf.toFixed(2)}</td></tr>`).join("")
    : `<tr><td colspan="5" class="muted">No defects</td></tr>`;
  $("#advice").innerHTML = renderAdvice(r.advice);
  $("#advisor-backend").textContent = r.advice ? "" : "(running on-device)";
  $("#op-status").textContent = "";
}

function showBanner(r) {
  const b = $("#alert-banner");
  const top = r.defects[0];
  b.className = "banner " + r.verdict;
  b.textContent = r.verdict === "PASS" ? `#${r.id} PASS` :
    `#${r.id} ${r.verdict} — ${r.defects.length} defect(s)${top ? `, worst: ${top.cls} (${top.severity}) at ${top.location}` : ""}`;
  clearTimeout(bannerTimer);
  bannerTimer = setTimeout(() => b.classList.add("hidden"), r.verdict === "PASS" ? 1500 : 6000);
}

async function pollLatest() {
  try {
    const r = await api("/api/latest");
    if (r && (r.id !== shownId || JSON.stringify(r.advice) !== shownAdvice || r.final_verdict !== $("#verdict").dataset.fv)) {
      const isNew = r.id !== shownId;
      shownId = r.id; shownAdvice = JSON.stringify(r.advice); $("#verdict").dataset.fv = r.final_verdict;
      renderLatest(r);
      if (isNew) { showBanner(r); if (r.verdict !== "PASS") beep(r.verdict); }
    }
  } catch (e) { console.warn(e); }
}
setInterval(pollLatest, 700);
pollLatest();

$("#btn-inspect").onclick = () => post("/api/inspect");
$("#btn-next").onclick = () => post("/api/next");
$("#btn-pause").onclick = async () => {
  const r = await post("/api/pause");
  $("#btn-pause").textContent = r.paused ? "Resume auto" : "Pause auto";
};
$("#btn-ref").onclick = async () => {
  const r = await post("/api/reference");
  $("#op-status").textContent = r.ok ? "Golden board captured from current frame." : "No frame available.";
};
$("#upload").onchange = async (e) => {
  const f = e.target.files[0]; if (!f) return;
  const fd = new FormData(); fd.append("image", f);
  const r = await api("/api/upload", { method: "POST", body: fd });
  renderLatest(r); shownId = r.id; showBanner(r);
  e.target.value = "";
};
$$(".op-buttons button").forEach((b) => b.onclick = async () => {
  if (!shownId) return;
  const r = await post(`/api/inspections/${shownId}/action`, { action: b.dataset.action, note: $("#op-note").value });
  renderLatest(r); $("#op-note").value = "";
  $("#op-status").textContent = `Recorded: ${b.textContent}`;
});
document.addEventListener("keydown", (e) => {
  if (["INPUT", "SELECT", "TEXTAREA"].includes(document.activeElement.tagName)) return;
  if (e.code === "Space") { e.preventDefault(); post("/api/inspect"); }
  if (e.key === "n" || e.key === "N") post("/api/next");
});

// ---------------- log tab
function kpis(el, s) {
  el.innerHTML = [["Inspected", s.total], ["Yield", s.yield_pct + "%"], ["PASS", s.by_verdict.PASS],
    ["REWORK", s.by_verdict.REWORK], ["REJECT", s.by_verdict.REJECT]].map(([k, v]) => `<div class="kpi"><b>${esc(v)}</b><span>${k}</span></div>`).join("");
}
async function loadLog() {
  const v = $("#log-filter").value;
  const [rows, st] = await Promise.all([api(`/api/inspections?limit=100${v ? "&verdict=" + v : ""}`), api("/api/stats?hours=8")]);
  kpis($("#kpis"), st);
  $("#log-body").innerHTML = rows.map((r) => `<tr>
    <td>${r.id}</td><td>${esc(r.time)}</td>
    <td><a href="${r.annotated_url}" target="_blank"><img src="${r.annotated_url}" loading="lazy"></a></td>
    <td class="v ${r.verdict}">${r.verdict}</td><td class="v ${r.final_verdict}">${r.final_verdict}${r.operator_action ? `<div class="muted small">${esc(r.operator_action)}</div>` : ""}</td>
    <td>${r.score}</td><td>${r.defects.map((d) => `${esc(d.cls)} ${sevBadge(d.severity)}`).join("<br>") || "—"}</td>
    <td class="adv">${esc((r.advice || {}).alert || "…")}</td><td class="small muted">${esc(r.vision_backend)}<br>${Math.round(r.vision_ms)} ms</td></tr>`).join("");
}
$("#log-refresh").onclick = loadLog;
$("#log-filter").onchange = loadLog;

// ---------------- jobs (Llama runs asynchronously)
async function waitJob(id, onTick) {
  for (let i = 0; i < 600; i++) {
    const j = await api(`/api/jobs/${id}`);
    if (j.status === "done" || j.status === "error") return j;
    onTick && onTick(j, i);
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error("timeout");
}

// ---------------- ask tab
function addMsg(cls, html) {
  const d = document.createElement("div"); d.className = "msg " + cls; d.innerHTML = html;
  $("#chat-log").appendChild(d); $("#chat-log").scrollTop = 1e9; return d;
}
async function ask(q) {
  addMsg("user", esc(q));
  const bot = addMsg("bot", `<span class="muted">Thinking on-device…</span>`);
  try {
    const { job } = await post("/api/ask", { question: q });
    const j = await waitJob(job, (_, i) => { bot.innerHTML = `<span class="muted">Thinking on-device… ${(i / 2).toFixed(0)} s</span>`; });
    const r = j.result;
    const st = r.stats || {};
    bot.innerHTML = r.error ? `Error: ${esc(r.error)}` :
      `${esc(r.answer)}<span class="meta">${esc(r.backend)} · ${(r.latency_ms / 1000).toFixed(1)} s${st.tokens_per_s ? ` · ${st.tokens_per_s} tok/s` : ""}</span>`;
  } catch (e) { bot.textContent = "Error: " + e.message; }
}
$("#ask-form").onsubmit = (e) => { e.preventDefault(); const q = $("#ask-input").value.trim(); if (q) { $("#ask-input").value = ""; ask(q); } };
$$(".chip").forEach((c) => c.onclick = () => ask(c.textContent));

// ---------------- report tab
$("#btn-report").onclick = async () => {
  const hours = +$("#report-hours").value;
  $("#report-summary").innerHTML = `<span class="muted">Generating with Llama on-device…</span>`;
  const { job, stats } = await post("/api/report", { hours });
  kpis($("#report-kpis"), stats);
  const max = Math.max(1, ...stats.top_defects.map((x) => x[1]));
  $("#bars").innerHTML = stats.top_defects.length ? stats.top_defects.map(([c, n]) =>
    `<div class="bar"><span>${esc(c)}</span><div style="width:${(100 * n) / max}%"></div><b>${n}</b></div>`).join("") : `<span class="muted">No defects in this window.</span>`;
  const j = await waitJob(job);
  const r = j.result;
  $("#report-summary").classList.remove("muted");
  $("#report-summary").textContent = r.error ? "Error: " + r.error : r.summary;
  $("#report-backend").textContent = r.backend ? `(${r.backend}, ${(r.latency_ms / 1000).toFixed(1)} s)` : "";
};

// ---------------- system tab
function dl(el, obj) { el.innerHTML = Object.entries(obj).map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(typeof v === "object" ? JSON.stringify(v) : v)}</dd>`).join(""); }
async function loadStatus() {
  const s = await api("/api/status");
  dl($("#sys-vision"), { backend: s.vision.backend, "last latency (ms)": s.vision.last_ms, "golden reference": s.vision.reference_set ? "set" : "per-image / not set",
    "backends not loaded": Object.keys(s.vision.errors).length ? s.vision.errors : "—", inspections: s.inspections });
  const a = s.advisor;
  dl($("#sys-llm"), { backend: a.backend, "Llama loaded": a.llama_loaded, "load error": a.error || "—", "queue length": a.queue, busy: a.busy,
    "last run": Object.keys(a.last).length ? a.last : "—", "cached patterns": a.cache_entries });
  dl($("#sys-cam"), { source: s.camera.kind, fps: s.camera.fps, error: s.camera.error || "—", "auto inspect": s.auto_inspect && !s.paused, uptime_s: s.uptime_s });
}
setInterval(() => { if ($("#tab-system").classList.contains("active")) loadStatus(); }, 3000);
