# NethraQC — architecture

NethraQC is an on-device quality-control assistant for bare-PCB inspection. Everything runs on the edge
device (Raspberry Pi 5 CPU-only, or any Arm Linux board) with **no network dependency**.

The system has **two separate inference pipelines** that share nothing but a message queue:

| | Vision pipeline | Advisory pipeline |
|---|---|---|
| Purpose | Find defects, locate and classify them | Explain the decision, recommend actions, answer questions, write shift summaries |
| Models | YOLO11n detector (6 PCB classes) + golden-board comparison (OpenCV, no training) | **Llama 3.2 1B Instruct**, 8da4w (4-bit weights, 8-bit dynamic activations) |
| Runtime | **ExecuTorch** (.pte, XNNPACK delegate) on the Arm CPU — ONNX Runtime as fallback. On a Pi 5 with AI HAT+, a HailoRT backend would run this pipeline on the Hailo NPU. | **ExecuTorch** Llama runner (`llama_main`, XNNPACK + KleidiAI int4 kernels) on the Arm CPU — always |
| Latency budget | real time: ~100–300 ms per board | asynchronous: seconds; never blocks inspection |
| Decides the verdict? | No — produces detections | No — explains a verdict it is not allowed to change |

The **verdict** (PASS / REWORK / REJECT) is decided by a deterministic, auditable **rule engine**
(`severity` section of `nethra/core.py`) between the two pipelines. The LLM never makes the accept/reject decision.

```mermaid
flowchart LR
  CAM[Camera / Pi Camera / image folder] --> PRE[Frame grabber<br/>latest-frame only]
  PRE --> TRIG{Trigger<br/>new part / stable frame / manual}
  subgraph VISION[Vision pipeline · real time]
    TRIG --> YOLO[YOLO11n · ExecuTorch .pte<br/>XNNPACK on Arm CPU]
    TRIG --> REF[Golden-board comparison<br/>ORB+ECC align · copper diff · topology]
    YOLO --> MERGE[Merge detections]
    REF --> MERGE
  end
  MERGE --> SEV[Severity rule engine<br/>PASS / REWORK / REJECT]
  SEV --> LOG[(SQLite log + images)]
  SEV --> ALERT[UI banner · beep · GPIO stack light]
  SEV -- defect facts JSON --> Q[(priority queue)]
  subgraph ADVISOR[Advisory pipeline · async]
    Q --> PROMPT[Prompt builder<br/>facts + SOP knowledge base]
    PROMPT --> LLAMA[Llama 3.2 1B · 8da4w<br/>ExecuTorch llama_main]
    LLAMA --> PARSE[Parse ALERT / ACTIONS / ROOT CAUSE]
  end
  PARSE --> LOG
  UI[Operator web UI<br/>inspect · log · ask · shift report] <--> LOG
  UI -- questions / report requests --> Q
```

## Vision pipeline

1. **Frame source** (`nethra/vision.py`) — USB/CSI camera through V4L2, Picamera2, a video file, or an image
   folder. A thread keeps only the newest frame so a slow step never creates lag.
2. **Trigger** (`nethra/pipeline.py`) — inspects when a new part arrives (folder mode), when the scene has been
   still for N frames after motion (conveyor/fixture mode), or on the operator's *Inspect* button.
3. **YOLO detector** (`nethra/vision.py`) — letterbox to 640, run the `.pte` with the ExecuTorch Python runtime,
   decode the head (raw YOLO11 head with NMS, or NMS-free end-to-end heads), map boxes back.
4. **Golden-board comparison** (`nethra/vision.py`) — the classical AOI method, no training needed:
   ORB feature homography + ECC sub-pixel refinement aligns the golden image to the test image; Otsu
   segments copper in both; added/removed copper becomes candidate defects; misalignment slivers are
   removed by morphology and a "core pixel" test. The defect *type* comes from local topology:

   | change | topology test | class |
   |---|---|---|
   | extra copper | fewer conductors in the neighbourhood than on the golden board | short |
   | extra copper | touches a conductor | spur |
   | extra copper | isolated | spurious_copper |
   | missing copper | more conductor pieces than on the golden board | open |
   | missing copper | surrounded by copper | pin_hole |
   | missing copper | on a conductor edge | mouse_bite |

   If more than 8% of the board differs, the result is one **anomaly** (wrong part, flipped board,
   camera moved). This path is also the anomaly detector for defect types YOLO was never trained on.
5. **Merge** — reference findings that do not overlap a YOLO box are added with a note.

## Severity engine

Per-class base severity (`config.yaml → severity.base`), escalated one level when the defect is large,
plus a count rule for many minor defects. Low-confidence detections are kept but flagged
"verify manually". Quality score = 100 − Σ(5 minor, 20 major, 45 critical).

## Advisory pipeline (Llama + ExecuTorch)

* **Grounding** — `knowledge/pcb_sop.yaml` holds the line's SOP excerpts (what the defect is, process
  area, likely causes, actions, acceptance). The prompt contains only the inspection facts plus the
  SOP entries for the defect classes found, and asks for a fixed `ALERT / ACTIONS / ROOT CAUSE` format.
  A 1B model is reliable at rephrasing and prioritising given text; it is not asked to recall facts.
* **Runtime** — `nethra/advisor.py` calls the ExecuTorch Llama runner with the Llama 3 chat template and
  parses the generated text and the runner's `PyTorchObserver` stats (prompt tokens, time-to-first-token,
  decode tokens/s), which are logged and shown in the UI.
* **Scheduling** — one worker thread, priority queue: operator questions (0) › shift reports (1) ›
  per-board advice (2). Clean PASS boards skip the LLM. Identical defect patterns reuse cached advice.
* **Fallback** — if the model files are missing the app still runs with a clearly labelled template
  advisor, for UI development only. The submission build uses Llama.

## Data

`data/inspections.db` (SQLite, WAL) stores every inspection: timestamp, station, source, verdict,
final verdict after operator review, score, defects (class, severity, box, location, confidence),
vision backend and latency, Llama advice and its latency, operator action and note. Raw and annotated
images are saved under `data/images/YYYYMMDD/`. CSV export is available from the UI.

## Why these choices

* **Golden-board comparison + YOLO** — bare-board AOI in industry is reference-based; it works on day one
  with zero labelled data and catches unseen defect types. YOLO adds robust classification once trained
  on DeepPCB, and works without a perfectly aligned reference.
* **Rules decide, LLM explains** — verdicts must be deterministic and auditable; a 1B LLM is excellent
  at turning structured facts into operator language but should not be trusted with numeric thresholds.
* **Async LLM** — inspection throughput is bounded by vision (~100–300 ms) not by token generation.
