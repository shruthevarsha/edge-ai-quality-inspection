"""NethraQC — on-device visual inspection + Llama (ExecuTorch) advisory for PCB quality control."""

__version__ = "0.1.0"
