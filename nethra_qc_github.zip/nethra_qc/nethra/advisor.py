"""Llama advisory pipeline — Llama 3.2 1B Instruct, 4-bit, executed on the Arm CPU by ExecuTorch.

Separate from the vision pipeline: the vision side decides *what* is wrong and the rule engine decides
the verdict; Llama turns that into operator guidance, answers questions and writes shift summaries.

Runtime: the ExecuTorch Llama runner (`llama_main`, built from executorch/examples/models/llama with
the XNNPACK backend + KleidiAI kernels) is invoked with the exported `.pte` and tokenizer.
All generation happens on-device; nothing leaves the machine.

Work is done on one background thread with a priority queue so inspection never waits on the LLM:
operator questions (priority 0) > shift reports (1) > per-board advice (2).
"""
from __future__ import annotations

import itertools
import json
import logging
import os
import queue
import re
import subprocess
import threading
import time
import uuid
from pathlib import Path
from typing import Callable

from .core import Assessment, KnowledgeBase

log = logging.getLogger(__name__)

SYSTEM = ("You are NethraQC, an assistant for quality-control operators at a PCB inspection station. "
          "Use only the inspection facts and SOP notes provided. Be brief, concrete and practical. "
          "The verdict was decided by inspection rules; never change it.")


def llama3_chat(system: str, user: str, add_bos: bool = False) -> str:
    """Llama 3.x instruct chat template."""
    bos = "<|begin_of_text|>" if add_bos else ""
    return (f"{bos}<|start_header_id|>system<|end_header_id|>\n\n{system}<|eot_id|>"
            f"<|start_header_id|>user<|end_header_id|>\n\n{user}<|eot_id|>"
            f"<|start_header_id|>assistant<|end_header_id|>\n\n")


# ------------------------------------------------------------------ prompt builders
def advice_prompt(a: Assessment, kb: KnowledgeBase, station: str) -> str:
    lines = [f"Station {station}. Verdict: {a.verdict} (quality score {a.score}/100). Reason: {'; '.join(a.reasons)}."]
    if a.detections:
        lines.append("Defects found:")
        for i, d in enumerate(a.detections[:6], 1):
            extra = f" ({'; '.join(d.notes)})" if d.notes else ""
            lines.append(f"{i}. {kb.name(d.cls)} — {d.severity}, {d.location}, confidence {d.conf:.2f}{extra}")
    else:
        lines.append("Defects found: none.")
    classes = list(dict.fromkeys(d.cls for d in a.detections))[:3]
    if classes:
        lines.append("SOP notes:")
        lines += [kb.snippet(c) for c in classes]
    lines.append(f"Station rule for {a.verdict}: {kb.verdict_actions.get(a.verdict, '')}")
    lines.append("Reply in exactly this format:\nALERT: <one sentence for the operator>\nACTIONS:\n- <action>\n- <action>\n"
                 "- <action>\nROOT CAUSE: <most likely process cause in one sentence>")
    return "\n".join(lines)


def question_prompt(question: str, context: dict, kb: KnowledgeBase) -> str:
    parts = [f"Operator question: {question.strip()}"]
    if context.get("inspection"):
        ins = context["inspection"]
        defects = ", ".join(f"{d['cls']} ({d['severity']}, {d['location']})" for d in ins.get("defects", [])) or "none"
        parts.append(f"Current board: inspection #{ins['id']}, verdict {ins['verdict']}, defects: {defects}.")
    if context.get("stats"):
        s = context["stats"]
        parts.append(f"Shift so far: {s['total']} boards, {s['by_verdict']}, top defects {s['top_defects']}.")
    classes = kb.classes_in_text(question)
    if context.get("inspection"):
        classes += [d["cls"] for d in context["inspection"].get("defects", [])]
    classes = list(dict.fromkeys(classes))[:3]
    if classes:
        parts.append("SOP notes:\n" + "\n".join(kb.snippet(c) for c in classes))
    parts.append("Answer in at most 4 short sentences. If the SOP notes do not cover it, say so and suggest asking the shift engineer.")
    return "\n".join(parts)


def report_prompt(stats: dict, kb: KnowledgeBase) -> str:
    top = stats.get("top_defects", [])
    notes = "\n".join(kb.snippet(c, 2) for c, _ in top[:3])
    return (f"Shift data for station {stats.get('station')} from {stats.get('since')} to {stats.get('until')}:\n"
            f"Boards inspected: {stats['total']}. Verdicts: {stats['by_verdict']}. Yield (PASS rate): {stats['yield_pct']}%.\n"
            f"Defect counts: {dict(top)}. Busiest hour: {stats.get('peak_hour')}. Operator overrides: {stats.get('overrides', 0)}.\n"
            f"SOP notes for the top defects:\n{notes}\n"
            "Write a shift handover summary: 1) one-line overview, 2) the main quality problem and its most likely "
            "process cause, 3) two recommended actions for the next shift. Keep it under 120 words.")


def parse_advice(text: str) -> dict:
    out = {"alert": "", "actions": [], "root_cause": "", "raw": text.strip()}
    m = re.search(r"ALERT:\s*(.+)", text)
    if m:
        out["alert"] = m.group(1).strip()
    m = re.search(r"ACTIONS:\s*\n((?:\s*[-*\d.].*\n?)+)", text)
    if m:
        out["actions"] = [re.sub(r"^\s*(?:[-*]|\d+[.)])\s*", "", l).strip() for l in m.group(1).splitlines() if l.strip()][:4]
    m = re.search(r"ROOT CAUSE:\s*(.+)", text)
    if m:
        out["root_cause"] = m.group(1).strip()
    return out


# ------------------------------------------------------------------ backends
class ExecuTorchLlama:
    """Runs the ExecuTorch Llama runner as a subprocess and parses its output + PyTorchObserver stats."""
    name = "llama-executorch"

    def __init__(self, cfg: dict) -> None:
        self.runner, self.model, self.tokenizer = cfg["runner"], cfg["model"], cfg["tokenizer"]
        self.seq_len = int(cfg.get("max_seq_len", 768))
        self.temperature = float(cfg.get("temperature", 0.2))
        self.threads = int(cfg.get("cpu_threads", 0))
        self.timeout = float(cfg.get("timeout_s", 120))
        self.add_bos = bool(cfg.get("add_bos_in_prompt", True))
        self.extra_args = list(cfg.get("extra_args", []))
        missing = [p for p in (self.runner, self.model, self.tokenizer) if not Path(p).exists()]
        if missing:
            raise FileNotFoundError("missing: " + ", ".join(missing))
        if not os.access(self.runner, os.X_OK):
            raise PermissionError(f"{self.runner} is not executable (chmod +x)")

    def generate(self, system: str, user: str) -> tuple[str, dict]:
        prompt = llama3_chat(system, user, self.add_bos)
        cmd = [self.runner, f"--model_path={self.model}", f"--tokenizer_path={self.tokenizer}",
               f"--prompt={prompt}", f"--seq_len={self.seq_len}", f"--temperature={self.temperature}"]
        if self.threads > 0:
            cmd.append(f"--cpu_threads={self.threads}")
        cmd += self.extra_args
        t0 = time.perf_counter()
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=self.timeout)
        wall = time.perf_counter() - t0
        if proc.returncode != 0:
            raise RuntimeError(f"llama runner exited {proc.returncode}: {proc.stderr[-500:]}")
        text, stats = self.parse_output(proc.stdout + "\n" + proc.stderr, prompt)
        stats["wall_s"] = round(wall, 2)
        return text, stats

    @staticmethod
    def parse_output(out: str, prompt: str) -> tuple[str, dict]:
        stats: dict = {}
        m = re.search(r"PyTorchObserver\s*(\{.*\})", out)
        if m:
            try:
                o = json.loads(m.group(1))
                gen = o.get("generated_tokens", 0)
                dec_ms = o.get("inference_end_ms", 0) - o.get("prompt_eval_end_ms", 0)
                stats = {"prompt_tokens": o.get("prompt_tokens"), "generated_tokens": gen,
                         "ttft_ms": o.get("first_token_ms", 0) - o.get("inference_start_ms", 0),
                         "load_ms": o.get("model_load_end_ms", 0) - o.get("model_load_start_ms", 0),
                         "tokens_per_s": round(gen / (dec_ms / 1000), 2) if dec_ms > 0 else None}
            except (ValueError, TypeError):
                pass
        text = out
        marker = "<|start_header_id|>assistant<|end_header_id|>"
        if marker in text:
            text = text.split(marker)[-1]
        elif prompt.strip() and prompt.strip()[-200:] in text:
            text = text.split(prompt.strip()[-200:])[-1]
        for stop in ("<|eot_id|>", "<|end_of_text|>", "PyTorchObserver"):
            text = text.split(stop)[0]
        # drop runner log lines (glog style "I 00:00:01.234 executorch:...")
        lines = [l for l in text.splitlines() if not re.match(r"^[IWEF] \d\d:\d\d:\d\d", l) and not l.startswith("I tokenizers")]
        return "\n".join(lines).strip(), stats


class TemplateAdvisor:
    """Deterministic text built from the knowledge base. Used only when the Llama model is not
    installed (UI development / CI). It is clearly labelled in the UI and logs."""
    name = "template (Llama not loaded)"

    def __init__(self, kb: KnowledgeBase) -> None:
        self.kb = kb

    def advice(self, a: Assessment) -> str:
        if not a.detections:
            return f"ALERT: Board passed inspection.\nACTIONS:\n- {self.kb.verdict_actions.get('PASS', 'Release')}\nROOT CAUSE: none"
        top = a.detections[0]
        e = self.kb.entry(top.cls)
        acts = [self.kb.verdict_actions.get(a.verdict, "")] + e.get("actions", [])[:2]
        acts = "\n".join(f"- {x}" for x in acts if x)
        return (f"ALERT: {a.verdict} — {self.kb.name(top.cls)} ({top.severity}) at {top.location}.\nACTIONS:\n{acts}\n"
                f"ROOT CAUSE: {(e.get('likely_causes') or ['unknown'])[0]}")

    def generate(self, system: str, user: str) -> tuple[str, dict]:
        classes = self.kb.classes_in_text(user)
        if "shift handover" in user:
            return "Template mode: install the Llama .pte to generate shift summaries.\n" + user.split("SOP notes")[0], {}
        if classes:
            return " ".join(self.kb.snippet(c, 2) for c in classes[:2]), {}
        return "Template mode — the Llama model is not installed, so free-form answers are unavailable.", {}


# ------------------------------------------------------------------ service
class AdvisorService:
    def __init__(self, cfg: dict) -> None:
        acfg = cfg["advisor"]
        self.station = cfg["app"]["station_id"]
        self.kb = KnowledgeBase(acfg["knowledge_base"])
        self.template = TemplateAdvisor(self.kb)
        self.llm = None
        self.error = None
        if acfg.get("backend", "executorch") == "executorch":
            try:
                self.llm = ExecuTorchLlama(acfg)
            except Exception as e:
                self.error = f"{type(e).__name__}: {e}"
                log.warning("Llama not available, using template advisor: %s", self.error)
        self.cache_enabled = bool(acfg.get("cache", True))
        self.cache: dict[str, dict] = {}
        self.jobs: dict[str, dict] = {}
        self.q: queue.PriorityQueue = queue.PriorityQueue()
        self._counter = itertools.count()
        self.last_stats: dict = {}
        self.busy = False
        threading.Thread(target=self._worker, name="llama-advisor", daemon=True).start()

    @property
    def backend_name(self) -> str:
        return self.llm.name if self.llm else self.template.name

    def status(self) -> dict:
        return {"backend": self.backend_name, "llama_loaded": self.llm is not None, "error": self.error,
                "queue": self.q.qsize(), "busy": self.busy, "last": self.last_stats, "cache_entries": len(self.cache)}

    # --- public API (all asynchronous; return a job id) ---
    def submit_advice(self, a: Assessment, on_done: Callable[[dict], None]) -> str:
        return self._submit(2, "advice", {"assessment": a}, on_done)

    def submit_question(self, question: str, context: dict) -> str:
        return self._submit(0, "question", {"question": question, "context": context})

    def submit_report(self, stats: dict, on_done: Callable[[dict], None] | None = None) -> str:
        return self._submit(1, "report", {"stats": stats}, on_done)

    def job(self, job_id: str) -> dict | None:
        return self.jobs.get(job_id)

    # --- internals ---
    def _submit(self, prio: int, kind: str, payload: dict, cb=None) -> str:
        jid = uuid.uuid4().hex[:12]
        self.jobs[jid] = {"id": jid, "kind": kind, "status": "queued", "created": time.time()}
        self.q.put((prio, next(self._counter), jid, kind, payload, cb))
        if len(self.jobs) > 500:  # bounded history
            for k in sorted(self.jobs, key=lambda k: self.jobs[k]["created"])[:100]:
                self.jobs.pop(k, None)
        return jid

    def _run(self, kind: str, payload: dict) -> dict:
        if kind == "advice":
            a: Assessment = payload["assessment"]
            if a.verdict == "PASS" and not a.detections:
                # Nothing to explain: don't spend CPU on the LLM for clean boards
                return {**parse_advice(self.template.advice(a)), "backend": "rule (clean board)", "stats": {}}
            key = a.signature()
            if self.cache_enabled and key in self.cache:
                return {**self.cache[key], "cached": True}
            if self.llm:
                text, stats = self.llm.generate(SYSTEM, advice_prompt(a, self.kb, self.station))
                backend = self.llm.name
            else:
                text, stats, backend = self.template.advice(a), {}, self.template.name
            res = {**parse_advice(text), "backend": backend, "stats": stats}
            if not res["alert"]:  # model ignored the format: keep raw text as the alert
                res["alert"] = res["raw"].split("\n")[0][:200]
            if self.cache_enabled:
                self.cache[key] = res
            return res
        if kind == "question":
            gen = self.llm or self.template
            text, stats = gen.generate(SYSTEM, question_prompt(payload["question"], payload["context"], self.kb))
            return {"answer": text, "backend": gen.name, "stats": stats}
        if kind == "report":
            gen = self.llm or self.template
            text, stats = gen.generate(SYSTEM, report_prompt(payload["stats"], self.kb))
            return {"summary": text, "backend": gen.name, "stats": stats}
        raise ValueError(kind)

    def _worker(self) -> None:
        while True:
            _, _, jid, kind, payload, cb = self.q.get()
            job = self.jobs.get(jid, {})
            job["status"] = "running"
            self.busy = True
            t0 = time.perf_counter()
            try:
                res = self._run(kind, payload)
                res["latency_ms"] = round((time.perf_counter() - t0) * 1000)
                if res.get("stats"):
                    self.last_stats = {**res["stats"], "kind": kind, "latency_ms": res["latency_ms"]}
                job.update(status="done", result=res)
            except Exception as e:
                log.exception("advisor job failed")
                res = {"error": f"{type(e).__name__}: {e}"}
                job.update(status="error", result=res)
            finally:
                self.busy = False
            if cb:
                try:
                    cb(res)
                except Exception:
                    log.exception("advisor callback failed")
