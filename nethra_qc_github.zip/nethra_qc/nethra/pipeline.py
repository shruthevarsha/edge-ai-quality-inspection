"""Orchestrates camera -> vision -> severity -> log -> alert -> (async) Llama advice."""
from __future__ import annotations

import logging
import threading
import time
from pathlib import Path

import cv2
import numpy as np

from .advisor import AdvisorService
from .core import Assessment, GpioAlerts, InspectionStore, assess
from .vision import Detector, FolderSource, open_source

log = logging.getLogger(__name__)

SEV_COLOR = {"critical": (40, 40, 230), "major": (0, 150, 255), "minor": (0, 220, 255)}
VERDICT_COLOR = {"PASS": (60, 180, 60), "REWORK": (0, 150, 255), "REJECT": (40, 40, 220)}


def annotate(img: np.ndarray, a: Assessment) -> np.ndarray:
    out = img.copy()
    h, w = out.shape[:2]
    th = max(1, round(min(h, w) / 400))
    for i, d in enumerate(a.detections, 1):
        c = SEV_COLOR.get(d.severity, (255, 255, 255))
        x1, y1, x2, y2 = d.box
        if (x2 - x1) * (y2 - y1) > 0.9 * w * h:   # whole-board anomaly: frame the image instead
            cv2.rectangle(out, (2, 2), (w - 3, h - 3), c, th * 3)
        else:
            m = 6  # pad small boxes so they are visible on the floor display
            cv2.rectangle(out, (x1 - m, y1 - m), (x2 + m, y2 + m), c, th + 1)
        label = f"{i}:{d.cls} {d.conf:.2f}"
        (tw, tht), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.45 * th, th)
        ly = max(tht + 4, y1 - 8)
        cv2.rectangle(out, (x1 - 6, ly - tht - 4), (x1 - 6 + tw + 4, ly + 2), c, -1)
        cv2.putText(out, label, (x1 - 4, ly - 1), cv2.FONT_HERSHEY_SIMPLEX, 0.45 * th, (0, 0, 0), th, cv2.LINE_AA)
    bar = 30 * th
    cv2.rectangle(out, (0, 0), (w, bar), VERDICT_COLOR[a.verdict], -1)
    cv2.putText(out, f"{a.verdict}  score {a.score}  defects {len(a.detections)}", (10, int(bar * 0.72)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7 * th, (255, 255, 255), 2 * th, cv2.LINE_AA)
    return out


class InspectionPipeline:
    def __init__(self, cfg: dict) -> None:
        self.cfg = cfg
        self.station = cfg["app"]["station_id"]
        self.store = InspectionStore(cfg["app"]["data_dir"])
        self.detector = Detector(cfg)
        self.advisor = AdvisorService(cfg)
        self.alerts = GpioAlerts(cfg)
        self.source = open_source(cfg)
        self.reference: np.ndarray | None = None
        ref = cfg["inspection"].get("reference_image")
        if ref and Path(ref).exists():
            self.reference = cv2.imread(ref)
        self._ref_cache: dict[str, np.ndarray] = {}
        self._lock = threading.Lock()          # serialises inspections (loop thread + API uploads)
        self._view_lock = threading.Lock()
        self.view: np.ndarray | None = None
        self.view_seq = 0
        self.latest: dict | None = None
        self.latest_item = None
        self.latest_ts = 0.0
        self.paused = False
        self._manual = threading.Event()
        self.fps = 0.0
        self.inspect_count = 0
        self.started = time.time()
        threading.Thread(target=self._loop, name="pipeline", daemon=True).start()

    # ------------------------------------------------------------ status
    def status(self) -> dict:
        d = self.detector
        return {
            "station": self.station,
            "uptime_s": round(time.time() - self.started),
            "camera": {"kind": self.source.kind, "error": self.source.error, "fps": round(self.fps, 1)},
            "vision": {"backend": d.backend_name, "errors": d.backend_errors, "last_ms": round(d.last_latency_ms, 1),
                       "reference_set": self.reference is not None},
            "advisor": self.advisor.status(),
            "inspections": self.inspect_count,
            "paused": self.paused,
            "auto_inspect": self.cfg["inspection"]["auto_inspect"],
            "offline": True,
        }

    # ------------------------------------------------------------ controls
    def request_inspect(self) -> None:
        self._manual.set()

    def next_part(self) -> None:
        if isinstance(self.source, FolderSource):
            self.source.next()

    def set_reference_from_frame(self) -> bool:
        frame, _, _ = self.source.read()
        if frame is None:
            return False
        self.set_reference(frame)
        return True

    def set_reference(self, img: np.ndarray | None) -> None:
        self.reference = None if img is None else img.copy()
        if img is not None:
            p = Path(self.cfg["app"]["data_dir"]) / "golden_reference.png"
            cv2.imwrite(str(p), img)

    def _reference_for(self, meta: dict) -> np.ndarray | None:
        rp = meta.get("reference_path")
        if rp:
            if rp not in self._ref_cache:
                self._ref_cache[rp] = cv2.imread(rp)
                if len(self._ref_cache) > 64:
                    self._ref_cache.pop(next(iter(self._ref_cache)))
            return self._ref_cache[rp]
        return self.reference

    # ------------------------------------------------------------ core
    def inspect(self, img: np.ndarray, reference: np.ndarray | None, source: str) -> dict:
        with self._lock:
            dets, info = self.detector.detect(img, reference)
            a = assess(dets, img.shape, self.cfg)
            ann = annotate(img, a)
            ts = time.time()
            day = time.strftime("%Y%m%d", time.localtime(ts))
            folder = Path(self.cfg["app"]["data_dir"]) / "images" / day
            folder.mkdir(parents=True, exist_ok=True)
            stem = time.strftime("%H%M%S", time.localtime(ts)) + f"_{int(ts * 1000) % 1000:03d}"
            raw_p, ann_p = folder / f"{stem}.jpg", folder / f"{stem}_ann.jpg"
            cv2.imwrite(str(raw_p), img, [cv2.IMWRITE_JPEG_QUALITY, 90])
            cv2.imwrite(str(ann_p), ann, [cv2.IMWRITE_JPEG_QUALITY, 85])
            reasons = a.reasons + ([info["warning"]] if info.get("warning") else [])
            iid = self.store.add(ts=ts, station=self.station, source=source, image_path=str(raw_p), annotated_path=str(ann_p),
                                 verdict=a.verdict, score=a.score, n_defects=len(a.detections),
                                 defects=[d.to_dict() for d in a.detections], reasons=reasons,
                                 vision_backend=info["backend"], vision_ms=info["total_ms"])
            self.inspect_count += 1
            self.alerts.signal(a.verdict)

            def on_advice(res: dict, iid=iid) -> None:
                self.store.set_advice(iid, res)
                if self.latest and self.latest["id"] == iid:
                    self.latest = self.store.get(iid)

            self.advisor.submit_advice(a, on_advice)
            rec = self.store.get(iid)
            rec["vision_info"] = info
            self.latest = rec
            self.latest_ts = ts
            self._set_view(ann)
            log.info("#%d %s score=%d defects=%d (%s, %.0f ms)", iid, a.verdict, a.score, len(a.detections),
                     info["backend"], info["total_ms"])
            return rec

    def _set_view(self, img: np.ndarray) -> None:
        with self._view_lock:
            self.view = img
            self.view_seq += 1

    def get_view_jpeg(self, quality: int = 80) -> tuple[bytes | None, int]:
        with self._view_lock:
            v, s = self.view, self.view_seq
        if v is None:
            return None, s
        ok, buf = cv2.imencode(".jpg", v, [cv2.IMWRITE_JPEG_QUALITY, quality])
        return (buf.tobytes() if ok else None), s

    def _loop(self) -> None:
        icfg = self.cfg["inspection"]
        last_seq, last_item = -1, None
        prev_small, still, armed = None, 0, True
        t_fps, n_fps = time.time(), 0
        while True:
            frame, meta, seq = self.source.read()
            if frame is None or (seq == last_seq and not self._manual.is_set()):
                time.sleep(0.01)
                continue
            last_seq = seq
            n_fps += 1
            if time.time() - t_fps >= 1.0:
                self.fps, n_fps, t_fps = n_fps / (time.time() - t_fps), 0, time.time()

            trigger = None
            if self._manual.is_set():
                self._manual.clear()
                trigger = "manual"
            elif icfg["auto_inspect"] and not self.paused:
                if meta.get("new_item") and meta.get("item") != last_item:
                    trigger = "auto"
                elif self.source.kind in ("camera", "picamera2", "video"):
                    small = cv2.cvtColor(cv2.resize(frame, (160, 120)), cv2.COLOR_BGR2GRAY).astype(np.int16)
                    if prev_small is not None:
                        motion = float(np.abs(small - prev_small).mean())
                        if motion < icfg["motion_threshold"]:
                            still += 1
                        else:
                            still = 0
                            if motion > icfg["motion_threshold"] * 2:
                                armed = True  # the part changed: allow the next inspection
                        if armed and still >= icfg["stable_frames"]:
                            trigger, armed = "auto-stable", False
                    prev_small = small
            if trigger:
                last_item = meta.get("item")
                src = meta.get("path") or f"{self.source.kind}:{trigger}"
                try:
                    self.inspect(frame, self._reference_for(meta), src)
                except Exception:
                    log.exception("inspection failed")
                continue
            # live view: keep the annotated result on screen for the current folder item / for 3 s on camera
            same_item = meta.get("path") and self.latest and self.latest.get("source") == meta.get("path")
            if not same_item and time.time() - self.latest_ts > 3.0:
                live = frame.copy()
                cv2.putText(live, f"LIVE  {self.fps:4.1f} fps", (10, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2, cv2.LINE_AA)
                self._set_view(live)
