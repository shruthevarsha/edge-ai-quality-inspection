#!/usr/bin/env python3
"""Detector tools: prepare DeepPCB -> train YOLO (on a GPU: Kaggle/Colab) -> export to ExecuTorch + ONNX.

  python scripts/detector_tools.py prepare --root DeepPCB/PCBData --out datasets/deeppcb_yolo
  python scripts/detector_tools.py train   --data datasets/deeppcb_yolo/data.yaml --epochs 120
  python scripts/detector_tools.py export  --weights runs/pcb/deeppcb_y11n/weights/best.pt

Run any sub-command with --help for its options.
"""
from __future__ import annotations

import argparse
import random
import re
import shutil
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent


# ============================================================================
# prepare
# ============================================================================
# Convert the DeepPCB dataset to YOLO format.
#
# DeepPCB: https://github.com/tangsanli5201/DeepPCB  (1,500 template/test pairs, 640x640, 6 defect classes)
# Layout used by the dataset:
#     PCBData/groupXXXXX/XXXXX/<id>_test.jpg      defective image
#     PCBData/groupXXXXX/XXXXX/<id>_temp.jpg      golden template
#     PCBData/groupXXXXX/XXXXX_not/<id>.txt       annotations: x1,y1,x2,y2,type   (type 1..6)
#     PCBData/trainval.txt, PCBData/test.txt      official split
#
#   git clone https://github.com/tangsanli5201/DeepPCB
#   python scripts/detector_tools.py prepare --root DeepPCB/PCBData --out datasets/deeppcb_yolo
# DeepPCB type id -> NethraQC class index (order must match config.yaml detector.classes)
CLASSES = ["open", "short", "mouse_bite", "spur", "spurious_copper", "pin_hole"]
TYPE_TO_CLS = {1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5}
IMG_SIZE = 640


def read_split(root: Path, name: str) -> list[tuple[Path, Path]] | None:
    f = root / name
    if not f.exists():
        return None
    pairs = []
    for line in f.read_text().split("\n"):
        parts = line.split()
        if len(parts) != 2:
            continue
        img, ann = root / parts[0], root / parts[1]
        test = img.with_name(img.stem + "_test" + img.suffix)
        pairs.append((test if test.exists() else img, ann))
    return pairs


def discover(root: Path) -> list[tuple[Path, Path]]:
    pairs = []
    for ann in root.rglob("*_not/*.txt"):
        img_dir = ann.parent.with_name(ann.parent.name[:-4])
        img = img_dir / f"{ann.stem}_test.jpg"
        if img.exists():
            pairs.append((img, ann))
    return sorted(pairs)


def convert(ann: Path) -> list[str]:
    out = []
    for line in ann.read_text().strip().splitlines():
        v = [int(float(x)) for x in re.split(r"[,\s]+", line.strip()) if x]
        if len(v) != 5 or v[4] not in TYPE_TO_CLS:
            continue
        x1, y1, x2, y2, t = v
        cx, cy = (x1 + x2) / 2 / IMG_SIZE, (y1 + y2) / 2 / IMG_SIZE
        w, h = (x2 - x1) / IMG_SIZE, (y2 - y1) / IMG_SIZE
        out.append(f"{TYPE_TO_CLS[t]} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}")
    return out


def cmd_prepare(argv: list[str]) -> None:
    ap = argparse.ArgumentParser(prog="detector_tools.py prepare")
    ap.add_argument("--root", required=True, help="path to DeepPCB/PCBData")
    ap.add_argument("--out", default="datasets/deeppcb_yolo")
    ap.add_argument("--val-frac", type=float, default=0.15, help="used only if the official split files are missing")
    ap.add_argument("--demo-pairs", type=int, default=20, help="also copy N test/template pairs to samples/deeppcb for the app demo")
    a = ap.parse_args(argv)
    root, out = Path(a.root), Path(a.out)
    train, val = read_split(root, "trainval.txt"), read_split(root, "test.txt")
    if not train or not val:
        allp = discover(root)
        random.Random(0).shuffle(allp)
        n_val = int(len(allp) * a.val_frac)
        val, train = allp[:n_val], allp[n_val:]
    counts = [0] * len(CLASSES)
    for split, pairs in (("train", train), ("val", val)):
        (out / "images" / split).mkdir(parents=True, exist_ok=True)
        (out / "labels" / split).mkdir(parents=True, exist_ok=True)
        for img, ann in pairs:
            if not img.exists() or not ann.exists():
                continue
            labels = convert(ann)
            for l in labels:
                counts[int(l.split()[0])] += 1
            shutil.copy(img, out / "images" / split / img.name)
            (out / "labels" / split / f"{img.stem}.txt").write_text("\n".join(labels) + "\n")
    (out / "data.yaml").write_text(
        f"path: {out.resolve()}\ntrain: images/train\nval: images/val\nnames:\n" + "".join(f"  {i}: {c}\n" for i, c in enumerate(CLASSES)))
    print(f"train={len(train)} val={len(val)} -> {out}")
    print("instances:", dict(zip(CLASSES, counts)))
    if a.demo_pairs:
        demo = Path(__file__).resolve().parent.parent / "samples" / "deeppcb"
        demo.mkdir(parents=True, exist_ok=True)
        for img, _ in val[: a.demo_pairs]:
            tmp = img.with_name(img.name.replace("_test", "_temp"))
            shutil.copy(img, demo / img.name)
            if tmp.exists():
                shutil.copy(tmp, demo / tmp.name)
        print(f"copied {a.demo_pairs} demo pairs to {demo}")


# ============================================================================
# train
# ============================================================================
# Train the PCB defect detector. Run this on a free GPU (Kaggle / Google Colab), not on the edge device.
#
#   pip install ultralytics
#   python scripts/detector_tools.py prepare --root DeepPCB/PCBData --out datasets/deeppcb_yolo
#   python scripts/detector_tools.py train --data datasets/deeppcb_yolo/data.yaml --epochs 120
#
# Outputs runs/pcb/<name>/weights/best.pt — then run: detector_tools.py export.
def cmd_train(argv: list[str]) -> None:
    ap = argparse.ArgumentParser(prog="detector_tools.py train")
    ap.add_argument("--data", required=True)
    ap.add_argument("--model", default="yolo11n.pt", help="yolo11n.pt (fastest on Arm CPU) or yolo11s.pt (more accurate)")
    ap.add_argument("--epochs", type=int, default=120)
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--name", default="deeppcb_y11n")
    ap.add_argument("--device", default=None, help="0 for first GPU, cpu for CPU")
    a = ap.parse_args(argv)

    from ultralytics import YOLO

    model = YOLO(a.model)
    model.train(
        data=a.data, epochs=a.epochs, imgsz=a.imgsz, batch=a.batch, device=a.device,
        project="runs/pcb", name=a.name, patience=30, cos_lr=True,
        # PCB images are top-down and orientation-free: flips are safe, colour jitter kept small
        fliplr=0.5, flipud=0.5, degrees=0.0, hsv_h=0.0, hsv_s=0.2, hsv_v=0.3, mosaic=1.0, close_mosaic=15,
    )
    metrics = model.val(data=a.data, imgsz=a.imgsz)
    print("mAP50:", round(metrics.box.map50, 4), "mAP50-95:", round(metrics.box.map, 4))
    for i, name in model.names.items():
        try:
            p, r, ap50, ap = metrics.box.class_result(i)
            print(f"  {name:16s} P={p:.3f} R={r:.3f} AP50={ap50:.3f}")
        except Exception:
            pass


# ============================================================================
# export
# ============================================================================
# Export the trained YOLO detector for on-device inference.
#
#   python scripts/detector_tools.py export --weights runs/pcb/deeppcb_y11n/weights/best.pt
#       -> models/pcb_yolo_xnnpack.pte   ExecuTorch program, XNNPACK-delegated (runs on the Arm CPU)
#       -> models/pcb_yolo.onnx          ONNX Runtime fallback
#
#   int8 (static PT2E quantization, needs executorch>=1.6 and calibration data):
#   python scripts/detector_tools.py export --weights best.pt --int8 --data datasets/deeppcb_yolo/data.yaml
#
# Uses Ultralytics' built-in ExecuTorch exporter (torch.export -> to_edge_transform_and_lower with the
# XnnpackPartitioner -> .pte).  pip install "ultralytics>=8.4" executorch onnx onnxruntime


def verify(pte: Path, onnx_path: Path | None, size: int) -> None:
    """Run the exported models on the same input and compare outputs."""
    import torch
    from executorch.runtime import Runtime
    x = np.random.rand(1, 3, size, size).astype(np.float32)
    et = Runtime.get().load_program(str(pte)).load_method("forward").execute([torch.from_numpy(x)])[0].numpy()
    msg = f"ExecuTorch output {tuple(et.shape)}"
    if onnx_path and onnx_path.exists():
        import onnxruntime as ort
        s = ort.InferenceSession(str(onnx_path))
        on = s.run(None, {s.get_inputs()[0].name: x})[0]
        msg += f"; ONNX output {tuple(on.shape)}; max |diff| = {np.abs(et - on).max():.3g}"
    print(msg)


def cmd_export(argv: list[str]) -> None:
    ap = argparse.ArgumentParser(prog="detector_tools.py export")
    ap.add_argument("--weights", required=True, help="best.pt from: detector_tools.py train")
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--out-dir", default=str(ROOT / "models"))
    ap.add_argument("--int8", action="store_true", help="static int8 quantization (head kept in fp32)")
    ap.add_argument("--data", default=None, help="data.yaml used for int8 calibration")
    ap.add_argument("--skip-onnx", action="store_true")
    a = ap.parse_args(argv)

    from ultralytics import YOLO

    out = Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    model = YOLO(a.weights)
    names = list(model.names.values())

    kw = {"format": "executorch", "imgsz": a.imgsz}
    if a.int8:
        kw.update(int8=True, data=a.data)
    et_dir = Path(model.export(**kw))
    pte_src = et_dir / "model.pte" if et_dir.is_dir() else et_dir
    pte = out / ("pcb_yolo_xnnpack_int8.pte" if a.int8 else "pcb_yolo_xnnpack.pte")
    shutil.copy(pte_src, pte)
    print(f"ExecuTorch -> {pte} ({pte.stat().st_size / 1e6:.1f} MB)")

    onnx_path = None
    if not a.skip_onnx:
        onnx_src = Path(YOLO(a.weights).export(format="onnx", imgsz=a.imgsz, opset=17, simplify=True))
        onnx_path = out / "pcb_yolo.onnx"
        shutil.copy(onnx_src, onnx_path)
        print(f"ONNX       -> {onnx_path}")

    verify(pte, onnx_path, a.imgsz)
    print("\nSet in config.yaml:")
    print(f"  detector.classes: {names}")
    print(f"  detector.input_size: {a.imgsz}")
    if a.int8:
        print(f"  detector.executorch_model: models/{pte.name}")

COMMANDS = {"prepare": cmd_prepare, "train": cmd_train, "export": cmd_export}


def main() -> None:
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        print(__doc__)
        sys.exit(1)
    COMMANDS[sys.argv[1]](sys.argv[2:])


if __name__ == "__main__":
    main()
