#!/usr/bin/env bash
# Llama 3.2 1B Instruct on ExecuTorch for NethraQC.
#
#   ./scripts/llama_setup.sh export   # on Kaggle/Colab or any Linux box with >= 16 GB RAM
#                                     #   -> models/llama3_2_1b_instruct_8da4w.pte + models/tokenizer.model
#   ./scripts/llama_setup.sh build    # natively on the Raspberry Pi 5 / aarch64 board (also works on x86 Linux)
#                                     #   -> models/llama_main
#
# Environment variables: EXECUTORCH_DIR (default ~/executorch), CKPT_DIR (default ~/llama32_1b/original),
#                        CONTEXT (default 1024), GROUP (default 32), JOBS (default nproc), ET_BRANCH (default release/1.0)
#
# Before "export":
#   1. Accept the Llama 3.2 licence on https://huggingface.co/meta-llama/Llama-3.2-1B-Instruct
#   2. huggingface-cli download meta-llama/Llama-3.2-1B-Instruct --include "original/*" --local-dir ~/llama32_1b
# Before "build" on a 4 GB Pi: enable 4 GB swap (dphys-swapfile). The build takes ~20-40 min on a Pi 5.
#
# Flags follow the ExecuTorch Llama example (examples/models/llama/README.md). If your ExecuTorch version
# renames a flag, check that README in your checkout.
set -euo pipefail

EXECUTORCH_DIR="${EXECUTORCH_DIR:-$HOME/executorch}"
CKPT_DIR="${CKPT_DIR:-$HOME/llama32_1b/original}"
APP_MODELS="$(cd "$(dirname "$0")/.." && pwd)/models"
CONTEXT="${CONTEXT:-1024}"
GROUP="${GROUP:-32}"
JOBS="${JOBS:-$(nproc)}"
NAME="llama3_2_1b_instruct_8da4w"

checkout_executorch() {
  if [ ! -d "$EXECUTORCH_DIR" ]; then
    git clone --depth 1 --branch "${ET_BRANCH:-release/1.0}" https://github.com/pytorch/executorch.git "$EXECUTORCH_DIR"
  fi
  cd "$EXECUTORCH_DIR"
  git submodule sync && git submodule update --init --recursive
  if [ ! -d .venv ]; then python3 -m venv .venv; fi
  # shellcheck disable=SC1091
  source .venv/bin/activate
  pip install --upgrade pip
}

do_export() {
  checkout_executorch
  ./install_executorch.sh
  ./examples/models/llama/install_requirements.sh
  mkdir -p "$APP_MODELS"
  # 8da4w = 8-bit dynamic activations + 4-bit grouped weights -> XNNPACK with KleidiAI int4 kernels on Arm.
  # Embeddings are quantized to 4-bit as well, bringing the 1B model to roughly 1 GB.
  python -m examples.models.llama.export_llama \
    --model llama3_2 \
    --checkpoint "$CKPT_DIR/consolidated.00.pth" \
    --params "$CKPT_DIR/params.json" \
    -kv --use_sdpa_with_kv_cache \
    -X --xnnpack-extended-ops \
    -qmode 8da4w --group_size "$GROUP" \
    -d fp32 \
    --embedding-quantize "4,$GROUP" \
    --max_seq_length "$CONTEXT" --max_context_length "$CONTEXT" \
    --metadata '{"get_bos_id":128000, "get_eos_ids":[128009, 128001]}' \
    --output_name "$APP_MODELS/$NAME.pte"
  cp "$CKPT_DIR/tokenizer.model" "$APP_MODELS/tokenizer.model"
  echo "Done: $APP_MODELS/$NAME.pte + tokenizer.model — copy both to the device's models/ folder"
}

do_build() {
  sudo apt-get install -y --no-install-recommends cmake ninja-build build-essential git python3-venv python3-dev || true
  checkout_executorch
  ./install_requirements.sh
  # Core runtime + XNNPACK (KleidiAI kernels are used automatically on Arm) + LLM runner extensions
  if ! cmake --preset llm -DCMAKE_INSTALL_PREFIX=cmake-out -DCMAKE_BUILD_TYPE=Release; then
    echo "Preset 'llm' not available in this ExecuTorch version, using explicit flags"
    cmake -S . -B cmake-out -DCMAKE_INSTALL_PREFIX=cmake-out -DCMAKE_BUILD_TYPE=Release \
      -DEXECUTORCH_BUILD_XNNPACK=ON \
      -DEXECUTORCH_BUILD_KERNELS_OPTIMIZED=ON \
      -DEXECUTORCH_BUILD_KERNELS_QUANTIZED=ON \
      -DEXECUTORCH_BUILD_KERNELS_LLM=ON \
      -DEXECUTORCH_BUILD_EXTENSION_DATA_LOADER=ON \
      -DEXECUTORCH_BUILD_EXTENSION_FLAT_TENSOR=ON \
      -DEXECUTORCH_BUILD_EXTENSION_MODULE=ON \
      -DEXECUTORCH_BUILD_EXTENSION_TENSOR=ON \
      -DEXECUTORCH_BUILD_EXTENSION_LLM=ON \
      -DEXECUTORCH_BUILD_EXTENSION_LLM_RUNNER=ON \
      -DPYTHON_EXECUTABLE="$(which python)"
  fi
  cmake --build cmake-out -j"$JOBS" --target install --config Release
  cmake -S examples/models/llama -B cmake-out/examples/models/llama \
    -DCMAKE_INSTALL_PREFIX=cmake-out -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=OFF \
    -DPYTHON_EXECUTABLE="$(which python)"
  cmake --build cmake-out/examples/models/llama -j"$JOBS" --config Release
  mkdir -p "$APP_MODELS"
  cp cmake-out/examples/models/llama/llama_main "$APP_MODELS/llama_main"
  chmod +x "$APP_MODELS/llama_main"
  echo "Installed $APP_MODELS/llama_main. Smoke test:"
  echo "  $APP_MODELS/llama_main --model_path=$APP_MODELS/$NAME.pte --tokenizer_path=$APP_MODELS/tokenizer.model --prompt='Hello' --seq_len=64"
}

case "${1:-}" in
  export) do_export ;;
  build)  do_build ;;
  *) sed -n '2,8p' "$0"; exit 1 ;;
esac
