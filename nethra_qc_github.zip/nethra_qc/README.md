# NethraQC — offline AI quality-control assistant for PCB inspection

NethraQC inspects bare printed circuit boards on the factory floor. It finds and classifies
surface defects, decides PASS / REWORK / REJECT, alerts the operator, logs every board, and explains
each decision with a **Llama 3.2 1B** model running on-device through **ExecuTorch**. It runs on a
Raspberry Pi 5 (CPU only) or any Arm Linux board, with no cloud connection.

| Brief requirement | Where it is in NethraQC |
|---|---|
| Detect surface defects, cracks, anomalies | YOLO11n detector (ExecuTorch `.pte`) + golden-board comparison that flags any deviation, including unseen defect types and wrong/flipped boards |
| Classify defect type and severity | 6 PCB classes (open, short, mouse bite, spur, spurious copper, pin hole) + anomaly; rule-based minor/major/critical severity and a quality score |
| Alert operators with actionable recommendations | Full-width banner + beep + optional GPIO stack light; Llama advice in `ALERT / ACTIONS / ROOT CAUSE` form grounded in the line's SOPs; operator Q&A |
| Log inspection results | SQLite log with images, defects, advice, latencies and operator overrides; CSV export; Llama-written shift handover report |
| Real time at the edge, no cloud | ~100 ms vision on a 2-core laptop CPU; LLM runs asynchronously so it never blocks inspection; everything on-device |
| Llama via ExecuTorch (required) | `nethra/advisor.py` → ExecuTorch `llama_main` with `llama3_2_1b_instruct_8da4w.pte` |

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for the two-pipeline design (vision vs. Llama).

---

## 1. Quick start (laptop, 5 minutes, no models needed)

```bash
git clone <this repo> && cd nethra_qc
pip install numpy opencv-python-headless flask pyyaml
python app.py --no-llm                   # open http://localhost:8080
```

On first run the app generates 12 synthetic golden/defective board pairs in `samples/demo` (they are
not stored in the repository). On Windows use the same commands in Command Prompt (`py` instead of
`python` if needed). The demo cycles through the sample boards, inspects each one with the golden-board comparison,
and shows the verdict, defect table and log. `--no-llm` uses a labelled template advisor until the
Llama model is installed (step 3). **Keyboard:** `Space` = inspect now, `N` = next part.

Run the tests: `python -m pytest -q`

## 2. Train the defect detector (Kaggle/Colab GPU, ~30 min)

Training is not done on the edge device. On a free Kaggle or Colab GPU notebook:

```bash
git clone https://github.com/tangsanli5201/DeepPCB
pip install ultralytics executorch onnx onnxruntime
python scripts/detector_tools.py prepare --root DeepPCB/PCBData --out datasets/deeppcb_yolo
python scripts/detector_tools.py train   --data datasets/deeppcb_yolo/data.yaml --model yolo11n.pt --epochs 120
python scripts/detector_tools.py export  --weights runs/pcb/deeppcb_y11n/weights/best.pt
#   -> models/pcb_yolo_xnnpack.pte  (ExecuTorch)   models/pcb_yolo.onnx  (fallback)
# optional int8: add  --int8 --data datasets/deeppcb_yolo/data.yaml
```

Copy `models/pcb_yolo_xnnpack.pte` to the device's `models/` folder. `prepare` also copies 20 real DeepPCB
test/template pairs to `samples/deeppcb` for the demo: `python app.py --source samples/deeppcb`.

## 3. Llama 3.2 1B on ExecuTorch

1. Accept the Llama 3.2 licence on Hugging Face (`meta-llama/Llama-3.2-1B-Instruct`).
2. **Export** (on Kaggle/Colab or any Linux box with ≥16 GB RAM):
   ```bash
   git clone https://github.com/pytorch/executorch ~/executorch && cd ~/executorch
   ./install_executorch.sh && ./examples/models/llama/install_requirements.sh
   huggingface-cli download meta-llama/Llama-3.2-1B-Instruct --include "original/*" --local-dir ~/llama32_1b
   cd -  &&  CKPT_DIR=~/llama32_1b/original ./scripts/llama_setup.sh export
   #   -> models/llama3_2_1b_instruct_8da4w.pte  +  models/tokenizer.model
   ```
3. **Build the runner on the device** (Pi 5: ~30 min, once): `./scripts/llama_setup.sh build`
   → `models/llama_main`
4. Start normally: `python app.py`. The *System* tab shows `Llama loaded: true` with tokens/s and
   time-to-first-token for every run.

Flags in `llama_setup.sh` follow the ExecuTorch Llama example for the XNNPACK backend; if your
ExecuTorch version renames a flag, check `examples/models/llama/README.md` in that checkout.

## 4. Deploy on Raspberry Pi 5

```bash
sudo apt install -y python3-opencv python3-picamera2 python3-flask python3-yaml
python3 -m venv --system-site-packages .venv && . .venv/bin/activate
pip install executorch onnxruntime gpiozero
python app.py --source picamera2        # or --source 0 for a USB camera
```

Open `http://<pi-ip>:8080` on the Pi's touchscreen or any tablet/phone on the same local network
(no internet needed). Mount the camera top-down at a fixed height with diffuse lighting, place a
known-good board, press **Set golden board**, then inspect boards of the same design.
Auto-start on boot — save as `/etc/systemd/system/nethraqc.service`, then `sudo systemctl enable --now nethraqc`:

```ini
[Unit]
Description=NethraQC offline PCB inspection assistant
After=network.target

[Service]
User=pi
WorkingDirectory=/home/pi/nethra_qc
ExecStart=/home/pi/nethra_qc/.venv/bin/python app.py --source picamera2
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

**With an AI HAT+ (Hailo):** the vision model would be compiled to `.hef` and run through HailoRT on
the NPU (add a backend in `nethra/vision.py` next to `ExecuTorchBackend`); Llama keeps running on
the Arm CPU through ExecuTorch. The two pipelines are already separate.

## 5. Configuration

Everything is in `config.yaml`: camera source, detector backends and thresholds, golden-board
comparison tuning, severity rules per defect class, Llama runner paths and generation settings,
GPIO pins. The SOP text that grounds the advisor is in `knowledge/pcb_sop.yaml`; edit it to your
line's procedures.

## 6. Benchmarks for the report

```bash
python scripts/benchmark.py --images samples/demo          # vision accuracy + latency
python scripts/benchmark.py --images samples/demo --llm    # + Llama latency, tokens/s, TTFT
```

Measured while building this (x86 laptop-class CPU, 2 cores, golden-board path, 800×600 images):
precision/recall 1.00/1.00 on the 12 demo boards and 0.97/0.97 on a 60-board synthetic set,
~110 ms per board. The ExecuTorch export path was checked end to end with a smoke-test YOLO11n
(`.pte` output matched ONNX to 1.5e-4; YOLO forward 52 ms with ExecuTorch/XNNPACK vs 100 ms with ONNX
Runtime on the same CPU). Synthetic boards are cleaner than real camera images, so re-run on DeepPCB and on
your own boards for the report numbers. Llama numbers must be measured on your device.

## Project layout

```
app.py                     Flask server, REST API, MJPEG live stream
config.yaml                all settings
requirements.txt
nethra/
  core.py                  config, data types, severity rules, SOP knowledge base, SQLite log, GPIO alerts
  vision.py                camera sources, golden-board comparison, YOLO (ExecuTorch / ONNX Runtime)
  advisor.py               Llama 3.2 via ExecuTorch llama_main: prompts, output parsing, async queue
  pipeline.py              orchestration: triggers, inspection, annotation, logging, alerts
knowledge/pcb_sop.yaml     SOP excerpts that ground the advisor
templates/index.html       operator UI (styles inline; no external assets, works offline)
static/app.js              operator UI logic
scripts/
  make_demo_samples.py     synthetic PCB pairs with ground truth (run automatically on first start)
  detector_tools.py        prepare DeepPCB / train YOLO / export to ExecuTorch + ONNX
  llama_setup.sh           export Llama 3.2 1B to .pte / build llama_main on the device
  benchmark.py             accuracy + latency numbers for the report
tests/test_pipeline.py     pytest suite (includes a mock llama_main for CI)
docs/ARCHITECTURE.md       two-pipeline design
```

Models (`models/`), datasets, generated samples and runtime data (`data/`) are not committed; see `.gitignore`.

Licences: Llama 3.2 is under the Llama 3.2 Community License; DeepPCB is for research use; Ultralytics
YOLO is AGPL-3.0.
