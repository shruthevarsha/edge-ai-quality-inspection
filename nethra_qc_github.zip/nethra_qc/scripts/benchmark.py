#!/usr/bin/env python3
"""Accuracy + latency benchmark for the technical report.

  python scripts/benchmark.py --images samples/demo            # vision only
  python scripts/benchmark.py --images samples/demo --llm      # + one Llama advisory run per verdict type

Accuracy uses ground_truth.json (synthetic samples) or DeepPCB-style *_not/*.txt files when present.
Writes results to data/benchmark.json and prints a Markdown table you can paste into the report.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import statistics
import sys
import threading
import time
from pathlib import Path

import cv2

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from nethra.advisor import AdvisorService  # noqa: E402
from nethra.core import assess, load_config  # noqa: E402
from nethra.vision import IMG_EXT, Detector, find_reference_for, iou, is_template  # noqa: E402


def load_gt(folder: Path) -> dict[str, list[dict]]:
    f = folder / "ground_truth.json"
    return json.loads(f.read_text()) if f.exists() else {}


def match(preds, gts, thr=0.1):
    """Greedy class-aware matching. Returns tp, fp, fn and per-class counts."""
    used, tp, per = set(), 0, {}
    for p in preds:
        hit = None
        for j, g in enumerate(gts):
            if j not in used and g["cls"] == p.cls and iou(p.box, g["box"]) >= thr:
                hit = j
                break
        c = per.setdefault(p.cls, [0, 0, 0])
        if hit is None:
            c[1] += 1
        else:
            used.add(hit)
            tp += 1
            c[0] += 1
    for j, g in enumerate(gts):
        if j not in used:
            per.setdefault(g["cls"], [0, 0, 0])[2] += 1
    return tp, len(preds) - tp, len(gts) - len(used), per


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--images", default=str(ROOT / "samples/demo"))
    ap.add_argument("--config", default=None)
    ap.add_argument("--llm", action="store_true")
    ap.add_argument("--warmup", type=int, default=2)
    a = ap.parse_args()
    cfg = load_config(a.config)
    det = Detector(cfg)
    folder = Path(a.images)
    gt = load_gt(folder)
    files = sorted(p for p in folder.iterdir() if p.suffix.lower() in IMG_EXT and not is_template(p))
    lat, tot = [], {"tp": 0, "fp": 0, "fn": 0}
    per_cls: dict[str, list[int]] = {}
    verdict_ok = 0
    samples = {}
    for i, f in enumerate(files):
        img = cv2.imread(str(f))
        rp = find_reference_for(f)
        ref = cv2.imread(str(rp)) if rp else None
        t0 = time.perf_counter()
        dets, _ = det.detect(img, ref)
        a_ = assess(dets, img.shape, cfg)
        if i >= a.warmup or len(files) <= a.warmup:
            lat.append((time.perf_counter() - t0) * 1000)
        samples.setdefault(a_.verdict, a_)
        if f.name in gt:
            tp, fp, fn, per = match(a_.detections, gt[f.name])
            tot["tp"] += tp; tot["fp"] += fp; tot["fn"] += fn
            for k, v in per.items():
                c = per_cls.setdefault(k, [0, 0, 0])
                for j in range(3):
                    c[j] += v[j]
            # board-level: did we get defective vs clean right?
            verdict_ok += int((len(gt[f.name]) == 0) == (len(a_.detections) == 0))
    res = {
        "device": f"{platform.machine()} {platform.processor() or ''} cores={os.cpu_count()}".strip(),
        "vision_backend": det.backend_name,
        "images": len(files),
        "latency_ms": {"mean": round(statistics.mean(lat), 1), "p50": round(statistics.median(lat), 1),
                       "p95": round(sorted(lat)[int(0.95 * (len(lat) - 1))], 1), "fps": round(1000 / statistics.mean(lat), 1)} if lat else {},
    }
    if gt:
        p = tot["tp"] / max(1, tot["tp"] + tot["fp"])
        r = tot["tp"] / max(1, tot["tp"] + tot["fn"])
        res["accuracy"] = {"precision": round(p, 3), "recall": round(r, 3), "f1": round(2 * p * r / max(1e-9, p + r), 3),
                           "board_level_defect_detection": f"{verdict_ok}/{len(gt)}",
                           "per_class": {k: {"tp": v[0], "fp": v[1], "fn": v[2]} for k, v in sorted(per_cls.items())}}
    if a.llm:
        adv = AdvisorService(cfg)
        res["llm_backend"] = adv.backend_name
        runs = []
        for v, ass in samples.items():
            if not ass.detections:
                continue
            adv.cache.clear()
            done: dict = {}
            ev = threading.Event()
            adv.submit_advice(ass, lambda r, d=done, e=ev: (d.update(r), e.set()))
            ev.wait(cfg["advisor"]["timeout_s"] + 30)
            runs.append({"verdict": v, "latency_ms": done.get("latency_ms"), **(done.get("stats") or {}), "alert": done.get("alert")})
        res["llm_runs"] = runs
    out = Path(cfg["app"]["data_dir"]) / "benchmark.json"
    out.write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2))
    print("\n| Metric | Value |\n|---|---|")
    print(f"| Device | {res['device']} |\n| Vision backend | {res['vision_backend']} |")
    if lat:
        L = res["latency_ms"]
        print(f"| Vision latency (mean / p95) | {L['mean']} / {L['p95']} ms |\n| Throughput | {L['fps']} boards/s |")
    if gt:
        A = res["accuracy"]
        print(f"| Precision / Recall / F1 | {A['precision']} / {A['recall']} / {A['f1']} |\n| Board-level defect detection | {A['board_level_defect_detection']} |")
    for r in res.get("llm_runs", []):
        print(f"| Llama advice ({r['verdict']}) | {r.get('latency_ms')} ms, {r.get('tokens_per_s')} tok/s, TTFT {r.get('ttft_ms')} ms |")
    print(f"\nSaved {out}")


if __name__ == "__main__":
    main()
