"""Unit + integration tests.  Run:  python -m pytest -q"""
from __future__ import annotations

import json
import subprocess
import sys
import threading
import time
from pathlib import Path

import cv2
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from nethra.advisor import AdvisorService, ExecuTorchLlama, advice_prompt, parse_advice  # noqa: E402
from nethra.core import Detection, InspectionStore, KnowledgeBase, assess, load_config  # noqa: E402
from nethra.vision import Detector, decode_yolo  # noqa: E402

# Stand-in for ExecuTorch's `llama_main`: reproduces the runner's output format (echoed prompt, generated
# text, <|eot_id|>, PyTorchObserver stats line) so the subprocess integration is tested without the 1 GB
# model. It does NOT run a language model.
MOCK_RUNNER = r'''
import json
import re
import sys
import time

args = dict(a[2:].split("=", 1) for a in sys.argv[1:] if a.startswith("--") and "=" in a)
prompt = args.get("prompt", "")
user = prompt.split("<|start_header_id|>user<|end_header_id|>")[-1]
print("I 00:00:00.001 executorch:runner.cpp:44] Creating LLaMa runner", file=sys.stderr)
if "Reply in exactly this format" in user:
    m = re.search(r"Verdict: (\w+)", user)
    d = re.search(r"1\. ([^—]+) — (\w+), ([\w-]+)", user)
    v = m.group(1) if m else "PASS"
    what = f"{d.group(1).strip()} ({d.group(2)}) at {d.group(3)}" if d else "no defects"
    out = (f"ALERT: {v} — {what}.\nACTIONS:\n- Follow the station rule for {v}.\n- Check the process area named in the SOP.\n"
           f"- Log the defect location for trend analysis.\nROOT CAUSE: See SOP likely causes for this defect.")
elif "shift handover" in user:
    out = "Overview: mock summary of the shift.\nMain problem: mock.\nActions: 1) mock 2) mock"
else:
    out = "Mock answer: this is the test runner, not Llama."
time.sleep(0.05)
sys.stdout.write(prompt + out + "<|eot_id|>\n")
gen = len(out.split())
stats = {"prompt_tokens": len(prompt.split()), "generated_tokens": gen, "model_load_start_ms": 0, "model_load_end_ms": 900,
         "inference_start_ms": 900, "prompt_eval_end_ms": 1200, "first_token_ms": 1250, "inference_end_ms": 1200 + gen * 80}
print("PyTorchObserver " + json.dumps(stats))
'''


@pytest.fixture(scope="session")
def mock_runner(tmp_path_factory):
    p = tmp_path_factory.mktemp("runner") / "llama_main"
    p.write_text(f"#!{sys.executable}\n" + MOCK_RUNNER)
    p.chmod(0o755)
    return p


@pytest.fixture(scope="session")
def samples(tmp_path_factory):
    out = tmp_path_factory.mktemp("samples")
    subprocess.run([sys.executable, str(ROOT / "scripts/make_demo_samples.py"), "--out", str(out), "--n", "12"], check=True)
    return out


@pytest.fixture
def cfg(tmp_path, mock_runner):
    (tmp_path / "m.pte").write_bytes(b"x")
    (tmp_path / "t.model").write_bytes(b"x")
    return load_config(overrides={"app": {"data_dir": str(tmp_path / "data")},
                                  "advisor": {"runner": str(mock_runner), "model": str(tmp_path / "m.pte"), "tokenizer": str(tmp_path / "t.model")}})


# ---------------------------------------------------------------- vision
def test_reference_inspector_finds_all_synthetic_defects(samples, cfg):
    det = Detector(cfg)
    gt = json.loads((samples / "ground_truth.json").read_text())
    for name, boxes in gt.items():
        t = cv2.imread(str(samples / name))
        r = cv2.imread(str(samples / name.replace("_test", "_temp")))
        dets, info = det.detect(t, r)
        assert sorted(d.cls for d in dets) == sorted(b["cls"] for b in boxes), name
        assert info["reference"]["aligned"]


def test_wrong_board_is_flagged_as_anomaly(samples, cfg):
    det = Detector(cfg)
    t = cv2.imread(str(samples / "board_000_test.jpg"))
    wrong = cv2.flip(cv2.imread(str(samples / "board_001_temp.jpg")), 1)
    dets, info = det.detect(t, wrong)
    assert len(dets) == 1 and dets[0].cls == "anomaly"


def test_decode_yolo_raw_head_and_nms():
    classes = ["open", "short"]
    # 3 candidate boxes (cx, cy, w, h, s_open, s_short): two overlapping 'short', one 'open'
    cand = np.array([[100, 100, 20, 20, 0.1, 0.9], [102, 101, 20, 20, 0.1, 0.8], [300, 300, 10, 10, 0.7, 0.1]], np.float32)
    out = cand.T[None]  # (1, 4+nc, N)
    dets = decode_yolo(out, classes, 0.3, 0.45, 1.0, (0, 0), (640, 640))
    assert sorted(d.cls for d in dets) == ["open", "short"]
    s = [d for d in dets if d.cls == "short"][0]
    assert s.box == (90, 90, 110, 110) and abs(s.conf - 0.9) < 1e-6


def test_decode_yolo_letterbox_inverse():
    # 800x600 image letterboxed to 640: r=0.8, pad=(0, 80)
    out = np.array([[[400], [80 + 240], [16], [16], [0.95]]], np.float32)
    d = decode_yolo(out, ["spur"], 0.3, 0.45, 0.8, (0, 80), (600, 800))[0]
    assert d.box == (490, 290, 510, 310)


def test_decode_end2end_head():
    out = np.array([[[10, 20, 30, 40, 0.9, 1], [0, 0, 5, 5, 0.1, 0]]], np.float32)
    dets = decode_yolo(out, ["open", "short", "spur"], 0.3, 0.45, 1.0, (0, 0), (640, 640))
    assert len(dets) == 1 and dets[0].cls == "short" and dets[0].box == (10, 20, 30, 40)


# ---------------------------------------------------------------- severity
def _d(cls, conf=0.9, area=0.0005):
    return Detection(cls, conf, (10, 10, 20, 20), "yolo", area)


def test_severity_rules(cfg):
    assert assess([], (600, 800), cfg).verdict == "PASS"
    assert assess([_d("short")], (600, 800), cfg).verdict == "REJECT"
    assert assess([_d("mouse_bite")], (600, 800), cfg).verdict == "REWORK"
    assert assess([_d("spur")], (600, 800), cfg).verdict == "PASS"
    assert assess([_d("spur"), _d("pin_hole"), _d("spur")], (600, 800), cfg).verdict == "REWORK"   # minor count rule
    a = assess([_d("spur", area=0.01)], (600, 800), cfg)                                            # large area escalates
    assert a.detections[0].severity == "major" and a.verdict == "REWORK"
    a = assess([_d("spur", conf=0.35)], (600, 800), cfg)
    assert any("verify manually" in n for n in a.detections[0].notes)


# ---------------------------------------------------------------- advisor
def test_runner_output_parsing():
    prompt = "<|start_header_id|>user<|end_header_id|>\n\nhi<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n"
    out = ("I 00:00:00.010 executorch:runner.cpp:44] loading\n" + prompt +
           "ALERT: Reject.\nACTIONS:\n- a\n- b\nROOT CAUSE: etch<|eot_id|>\n"
           'PyTorchObserver {"prompt_tokens":50,"generated_tokens":20,"model_load_start_ms":0,"model_load_end_ms":800,'
           '"inference_start_ms":800,"prompt_eval_end_ms":1000,"first_token_ms":1050,"inference_end_ms":3000}\n')
    text, st = ExecuTorchLlama.parse_output(out, prompt)
    p = parse_advice(text)
    assert p["alert"] == "Reject." and p["actions"] == ["a", "b"] and p["root_cause"] == "etch"
    assert st["tokens_per_s"] == 10.0 and st["ttft_ms"] == 250


def test_prompt_is_grounded_in_sop(cfg):
    kb = KnowledgeBase(cfg["advisor"]["knowledge_base"])
    a = assess([_d("short")], (600, 800), cfg)
    p = advice_prompt(a, kb, "L1")
    assert "Verdict: REJECT" in p and "Under-etching" in p and "ROOT CAUSE:" in p


def test_advisor_service_with_mock_runner(cfg):
    svc = AdvisorService(cfg)
    assert svc.llm is not None, svc.error
    ev, res = threading.Event(), {}
    svc.submit_advice(assess([_d("open")], (600, 800), cfg), lambda r: (res.update(r), ev.set()))
    assert ev.wait(20)
    assert res["backend"] == "llama-executorch" and res["alert"].startswith("REJECT")
    jid = svc.submit_question("what causes shorts?", {})
    for _ in range(100):
        j = svc.job(jid)
        if j["status"] == "done":
            break
        time.sleep(0.05)
    assert j["status"] == "done" and j["result"]["answer"]


def test_template_fallback_when_model_missing(cfg):
    cfg["advisor"]["model"] = "/nonexistent.pte"
    svc = AdvisorService(cfg)
    assert svc.llm is None and "template" in svc.backend_name


# ---------------------------------------------------------------- store
def test_store_roundtrip_and_stats(tmp_path):
    s = InspectionStore(str(tmp_path))
    i1 = s.add(station="L1", verdict="REJECT", score=55, n_defects=1, defects=[{"cls": "short", "severity": "critical", "location": "center"}], reasons=["x"])
    s.add(station="L1", verdict="PASS", score=100, n_defects=0, defects=[], reasons=[])
    s.set_operator(i1, "override_pass", "cosmetic")
    st = s.stats()
    assert st["total"] == 2 and st["by_verdict"]["PASS"] == 2 and st["overrides"] == 1
    assert "short/critical@center" in s.export_csv()


# ---------------------------------------------------------------- web app
def test_flask_app_end_to_end(cfg, samples):
    cfg["camera"]["source"] = str(samples)
    cfg["camera"]["folder_interval_s"] = 0.3
    from app import create_app
    app = create_app(cfg)
    c = app.test_client()
    for _ in range(100):
        if c.get("/api/latest").json:
            break
        time.sleep(0.1)
    assert c.get("/api/latest").json["verdict"] in ("PASS", "REWORK", "REJECT")
    with open(samples / "board_001_test.jpg", "rb") as f1, open(samples / "board_001_temp.jpg", "rb") as f2:
        r = c.post("/api/upload", data={"image": (f1, "t.png"), "reference": (f2, "r.png")}, content_type="multipart/form-data").json
    assert r["verdict"] == "REJECT" and r["defects"][0]["cls"] == "short"
    assert c.post(f"/api/inspections/{r['id']}/action", json={"action": "reject"}).json["final_verdict"] == "REJECT"
    assert c.get("/api/status").json["advisor"]["llama_loaded"]
    assert c.get("/media/../../etc/passwd").status_code == 404
    assert c.get("/api/export.csv").status_code == 200
