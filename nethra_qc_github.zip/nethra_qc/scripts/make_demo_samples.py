#!/usr/bin/env python3
"""Generate synthetic PCB images (golden + defective pairs, with ground truth) for demos and tests.

Real data: use DeepPCB (template/test pairs, same naming) — see: scripts/detector_tools.py prepare.
These synthetic boards just let the app run out of the box with no dataset download.

  python scripts/make_demo_samples.py --out samples/demo --n 12
"""
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import cv2
import numpy as np

MASK = (40, 92, 28)        # solder-mask green (BGR)
COPPER = (70, 170, 215)    # tinned copper
HOLE = (25, 25, 25)
SILK = (235, 235, 235)
W, H = 800, 600


def draw_board(rng: random.Random) -> tuple[np.ndarray, dict]:
    img = np.full((H, W, 3), MASK, np.uint8)
    lanes = list(range(70, 430, 44))
    traces = []
    for y in lanes:
        x0 = rng.randint(40, 140)
        x1 = rng.randint(520, 600)
        tw = rng.choice([8, 10, 12])
        cv2.rectangle(img, (x0, y - tw // 2), (x1, y + tw // 2), COPPER, -1)
        for px in (x0, x1):
            cv2.circle(img, (px, y), 14, COPPER, -1)
            cv2.circle(img, (px, y), 5, HOLE, -1)
        traces.append({"y": y, "x0": x0, "x1": x1, "w": tw})
    # copper pour / ground plane (where pin holes live)
    pour = (640, 70, 760, 420)
    cv2.rectangle(img, pour[:2], pour[2:], COPPER, -1)
    # bottom connector pads
    for i in range(10):
        x = 120 + i * 50
        cv2.rectangle(img, (x, 500), (x + 26, 560), COPPER, -1)
    # silkscreen (identical on golden and test, gives alignment features)
    cv2.putText(img, "NETHRA-QC REV A", (60, 480), cv2.FONT_HERSHEY_SIMPLEX, 0.8, SILK, 2, cv2.LINE_AA)
    cv2.putText(img, f"SN {rng.randint(10000, 99999)}", (560, 480), cv2.FONT_HERSHEY_SIMPLEX, 0.7, SILK, 2, cv2.LINE_AA)
    for i in range(6):
        cv2.rectangle(img, (40 + i * 18, 30), (50 + i * 18, 44), SILK, 1)
    return img, {"traces": traces, "pour": pour}


def add_defect(img: np.ndarray, layout: dict, kind: str, rng: random.Random) -> tuple[int, int, int, int]:
    tr = layout["traces"]
    if kind == "short":
        i = rng.randrange(len(tr) - 1)
        a, b = tr[i], tr[i + 1]
        x = rng.randint(max(a["x0"], b["x0"]) + 40, min(a["x1"], b["x1"]) - 40)
        y1, y2 = a["y"] + a["w"] // 2, b["y"] - b["w"] // 2
        cv2.rectangle(img, (x, y1 - 1), (x + rng.randint(5, 9), y2 + 1), COPPER, -1)
        return x - 2, y1 - 2, x + 11, y2 + 2
    t = rng.choice(tr)
    x = rng.randint(t["x0"] + 60, t["x1"] - 60)
    y, w = t["y"], t["w"]
    if kind == "open":
        gw = rng.randint(6, 10)
        cv2.rectangle(img, (x, y - w // 2 - 1), (x + gw, y + w // 2 + 1), MASK, -1)
        return x - 2, y - w // 2 - 2, x + gw + 2, y + w // 2 + 2
    if kind == "mouse_bite":
        top = rng.random() < 0.5
        cy = y - w // 2 if top else y + w // 2
        cv2.circle(img, (x, cy), 4, MASK, -1)
        return x - 6, cy - 6, x + 6, cy + 6
    if kind == "spur":
        top = rng.random() < 0.5
        ln = rng.randint(7, 12)
        if top:
            cv2.rectangle(img, (x, y - w // 2 - ln), (x + 4, y - w // 2), COPPER, -1)
            return x - 2, y - w // 2 - ln - 2, x + 6, y - w // 2 + 2
        cv2.rectangle(img, (x, y + w // 2), (x + 4, y + w // 2 + ln), COPPER, -1)
        return x - 2, y + w // 2 - 2, x + 6, y + w // 2 + ln + 2
    if kind == "spurious_copper":
        # in the gap between two lanes, away from both
        i = rng.randrange(len(tr) - 1)
        cy = (tr[i]["y"] + tr[i + 1]["y"]) // 2
        cx = rng.randint(200, 480)
        r = rng.randint(4, 6)
        cv2.circle(img, (cx, cy), r, COPPER, -1)
        return cx - r - 2, cy - r - 2, cx + r + 2, cy + r + 2
    if kind == "pin_hole":
        x0, y0, x1, y1 = layout["pour"]
        cx, cy = rng.randint(x0 + 20, x1 - 20), rng.randint(y0 + 20, y1 - 20)
        r = rng.randint(3, 4)
        cv2.circle(img, (cx, cy), r, MASK, -1)
        return cx - r - 2, cy - r - 2, cx + r + 2, cy + r + 2
    raise ValueError(kind)


def camera_effects(img: np.ndarray, rng: random.Random, shift: bool) -> np.ndarray:
    out = img.astype(np.float32)
    out *= rng.uniform(0.92, 1.08)
    out += np.random.default_rng(rng.randint(0, 1 << 30)).normal(0, 4, out.shape)
    out = np.clip(out, 0, 255).astype(np.uint8)
    if shift:
        ang = rng.uniform(-0.6, 0.6)
        M = cv2.getRotationMatrix2D((W / 2, H / 2), ang, 1.0)
        M[:, 2] += (rng.uniform(-6, 6), rng.uniform(-6, 6))
        out = cv2.warpAffine(out, M, (W, H), borderMode=cv2.BORDER_REPLICATE)
    return cv2.GaussianBlur(out, (3, 3), 0)


PLANS = [
    [], ["short"], ["open"], ["mouse_bite"], ["spur"], ["spurious_copper"], ["pin_hole"],
    ["spur", "pin_hole"], ["open", "mouse_bite"], [], ["short", "spurious_copper"], ["mouse_bite", "spur", "pin_hole"],
]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="samples/demo")
    ap.add_argument("--n", type=int, default=12)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--no-shift", action="store_true", help="disable the small rotation/shift of test images")
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(a.seed)
    gt = {}
    for i in range(a.n):
        golden, layout = draw_board(rng)
        test = golden.copy()
        plan = PLANS[i % len(PLANS)]
        boxes = [{"cls": k, "box": list(add_defect(test, layout, k, rng))} for k in plan]
        name = f"board_{i:03d}"
        cv2.imwrite(str(out / f"{name}_temp.jpg"), camera_effects(golden, rng, False), [cv2.IMWRITE_JPEG_QUALITY, 92])
        # Note: GT boxes are in un-shifted coordinates; with shift enabled they are approximate (±6 px)
        cv2.imwrite(str(out / f"{name}_test.jpg"), camera_effects(test, rng, not a.no_shift), [cv2.IMWRITE_JPEG_QUALITY, 92])
        gt[f"{name}_test.jpg"] = boxes
    (out / "ground_truth.json").write_text(json.dumps(gt, indent=2))
    print(f"Wrote {a.n} board pairs to {out}")


if __name__ == "__main__":
    main()
